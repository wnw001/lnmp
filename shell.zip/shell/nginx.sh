#!/bin/bash
cp /root/ziliao/www.conf /usr/local/nginx/conf/vhost/www.conf
var=$(cat /root/host_name.txt)
sed -i "s/www.com/$(echo $var)/g" /usr/local/nginx/conf/vhost/www.conf
nginx -s reload


