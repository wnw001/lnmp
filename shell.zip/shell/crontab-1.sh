#!/bin/bash
HOSTNAME="localhost"
PORT="3306"
USERNAME="root"
PASSWORD="root123456"
DBNAME="new_blog"
TABLENAME="os_config"

select_sql="SELECT value from ${TABLENAME} where id=1"
yuming=$(mysql -h${HOSTNAME}  -P${PORT}  -u${USERNAME} -p${PASSWORD} ${DBNAME} -e "${select_sql}")
var=$(echo "$yuming" |awk -F '//' '{print $2}')
#sed -i 's/"$var"/www.com/g' /root/test/www.conf
sed -i "s/www.com/$(echo $var)/g" /usr/local/nginx/conf/vhost/www.conf
nginx -s reload
