#!/bin/bash
yum -y install zip && yum -y install unzip
wget -P /root http://soft.vpser.net/lnmp/lnmp1.6.tar.gz -cO lnmp1.6.tar.gz && tar zxf lnmp1.6.tar.gz
\cp /root/shell/main.sh /root/lnmp1.6/include/main.sh
\cp /root/shell/end.sh /root/lnmp1.6/include/end.sh
cd /root/lnmp1.6 && ./install.sh lnmp

