#!/bin/bash
yum -y install subversion
mkdir /home/svndata
svnserve -d -r /home/svndata
svnadmin create /home/svndata/svnwww
\cp /root/ziliao/passwd.txt /home/svndata/svnwww/conf/passwd
\cp /root/ziliao/svnserve.txt /home/svndata/svnwww/conf/svnserve.conf
\cp /root/ziliao/post-commit.txt /home/svndata/svnwww/hooks/post-commit
chmod +x /home/svndata/svnwww/hooks/post-commit
cd /home/svndata/www/
svn co svn://127.0.0.1/svnwww --username svn1113 --password svn123 --no-auth-cache
svn co svn://127.0.0.1/svnwww /home/wwwroot/svnwww --username svn1113 --password svn123 --no-auth-cache
chown -R www:www /home/wwwroot/svnwww

