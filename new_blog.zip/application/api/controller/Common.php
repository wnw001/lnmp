<?php
namespace app\api\controller;
use think\Controller;
use think\Config;
use think\cache\driver\Redis;
use think\Db;
use think\Session;
/**
 * @author wuningwen
 */
class Common extends Controller
{
    protected function _initialize()
    {
        parent::_initialize();
    }
    /*
     * 获取验证码
     * 
     */
    public function show_captcha(){
        $captcha = new \think\captcha\Captcha();
        $captcha->imageW = 121;
        $captcha->imageH = 32;  //图片高
        $captcha->fontSize = 14;  //字体大小
        $captcha->length = 4;  //字符数
        $captcha->fontttf = '5.ttf';  //字体
        $captcha->expire = 30;  //有效期
        $captcha->useNoise = false;  //不添加杂点
        return $captcha->entry();
    }
    
    /*
     * 查询条件
     */
    public function queryCriteria(){
        $redis_cache = new Redis();
        $cache_key = 'query_criteria';
        if($redis_cache->get($cache_key)){
            return json($redis_cache->get($cache_key));
        }else{
            $res = Db::name('query_criteria')->where('id=2')->find();
            $redis_cache->set($cache_key, $res);
            return json($redis_cache->get($cache_key));
        }
    }

    /*
     * 车辆类型
     */
    public function carType(){
        $redis_cache = new Redis();
        $cache_key = 'car_type';
        if($redis_cache->get($cache_key)){
            return json($redis_cache->get($cache_key));
        }else{
            $res = Db::name('car_type')->select();
            $redis_cache->set($cache_key, $res);
            return json($redis_cache->get($cache_key));
        }
    }
    /*
     * 地区表接口
     * $param rank 0:省 1：根据zone_id返回数据
     * @param zone_id 地区id
     */
    
    public function zone(){
        $rank = input('rank');
        $zone_id = input('zone_id');
        if($rank==0){
            $result = Db::name('zone')->where('rank='.$rank)->field('zone_id,zone_name')->select();
        }else{
            $result = Db::name('zone')->where('Affiliation='.$zone_id)->field('zone_id,zone_name')->select();
        }
        return json($result);
    }
}
