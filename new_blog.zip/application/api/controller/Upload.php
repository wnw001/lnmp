<?php
namespace app\api\controller;

use org\UeditorUpload;
use think\Controller;
use think\Session;
use think\Config;
/**
 * 通用上传接口
 * Class Upload
 * @package namespace app\admin\controller;
 */
class Upload extends Controller
{
    protected function _initialize()
    {
        parent::_initialize();
        Config::load(CONF_PATH . 'aliyun' . CONF_EXT);
        $this->site_img_url = Config::get('site_img_url');
        if (Session::has('admin_id') || Session::get('user_array')) {
            $result = [
                'error'   => 1,
                'message' => '未登录'
            ];
            return json($result);
        }
        //如需其他模块使用，请自己做判断$_SERVER['HTTP_REFERER']判断来源模块;
    }

    /**
     * 通用图片上传接口---到本地
     * @return \think\response\Json
     */
    public function upload()
    {
        $config = [
            'size' => 2097152,
            'ext'  => 'jpg,gif,png,bmp'
        ];

        $file = $this->request->file('file');

        $upload_path = str_replace('\\', '/', ROOT_PATH . 'public/uploads');
        $save_path   = '/uploads/';
        $info        = $file->validate($config)->move($upload_path);

        if ($info) {
            $result = [
                'error' => 0,
                'url'   => str_replace('\\', '/', $save_path . $info->getSaveName())
            ];
        } else {
            $result = [
                'error'   => 1,
                'message' => $file->getError()
            ];
        }
        return json($result);
    }
    /*
     * 上传图片到oss---单图上传接口
     */
    public function upload_oss(){
        $up = upload_img($_FILES, ['savePath' => 'editor/']);
            if ($up['code']) {
                $up_data = $up['msg'];
                foreach ($up_data as $k => $v) {
                    $data[$k] = $this->site_img_url . '/data/uploads/' . $v['savepath'] . $v['savename'];
                }
                return json(array('error' => 0, 'url' => $data['file']));
            } else {
                return json(array('error' => 1, 'message' => $up['msg']));
            }
        
       
}
}