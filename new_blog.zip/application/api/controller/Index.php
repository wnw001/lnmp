<?php

/**
 * @author wuningwen<524950576@qq.com>
 *
 */

namespace app\api\controller;

use think\Config;
use app\common\controller\ApiBase;
use think\cache\driver\Redis;
use think\Session;

class Index extends ApiBase {
    
    public $Controller = 'api';    
    protected function _initialize() {
        parent::_initialize(); 
    }
    /*
     * 路由解析
     */
    public function index() {
       
        $this->versions = Config::get('versions');
        $versions = array_slice($this->versions, 0, $this->versionIndex + 1);
        $versionss = array_reverse(array_values($versions));
        //异常处理
        $router = explode('/', $this->opact);
        if (!$router || !$router[0] || !$router[1]) {
            $this->apiError('错误的参数请求。');
        }
        $router[0] = $this->parse_name($router[0], 1);
        $cache_key = $this->Controller . 'ActionVersion:' . md5('v' . $this->version . 'c' . $router[0] . 'a' . $router[1]);
        $redis_cache = new Redis();
        $classpath = $redis_cache->get($cache_key);
        $requestmethod = $router[1];

        $requestmethod_alias = $this->parse_name($requestmethod, 1);
        if (!$classpath || $this->debug) {
            foreach ($versionss as $val) {
                $classpath = $this->Controller . '/controller/' . $val . '/' . $router[0];
                if (!file_exists(APP_PATH . $classpath . EXT)) {
                    continue;
                }
                $classpath = 'app\\' . $this->Controller . '\controller\\' . $val . '\\' . $router[0];
                $classpath = "\\" . $classpath;

                $tmpcontrol = new $classpath();
                if (method_exists($tmpcontrol, $requestmethod) || method_exists($tmpcontrol, $requestmethod_alias)) {
                    $redis_cache->set($cache_key, $classpath);
                    break;
                } else {
                    $classpath = '';
                }
            }
        } else {

            $tmpcontrol = new $classpath;
        }
        if ($classpath) {
            $rtndata = $tmpcontrol->$requestmethod();
            if (is_array($rtndata)) {
                $this->apiSuccess($rtndata);
            }
            exit;
        }
        $this->apiError('程序路径出错!');
        exit;
    }
    /**
     * 小程序---是否登录
     */
    private function isXcxLogin() {
        $token = input('token');
        $this->loginUser = cache('login_user_token_' . $token);
        if (!$this->loginUser) {
            $userToken = model('user_token')->getUserToken(['token' => $token]);
            if (empty($userToken)) {
                $this->apiError('请登录');
            }
            $this->loginUser = model('user_xcx_info')->getUserXcx(
                    ['id' => $userToken['u_x_id']], 'id,u_id,nickname,img_url'
            );
            if (empty($this->loginUser)) {
                $this->apiError('登录数据有误');
            }
            $this->loginUser['token'] = $token;
            cache('login_user_token_' . $token, $this->loginUser, 86400); //缓存1天
        }
    }    

}
