<?php

/*
 * 用户登陆注册模块
 * @author Ningwen Wu <524950576@qq.com> 
 */

namespace app\api\controller\V1;

use app\common\controller\ApiBase;
use think\Db;
use app\common\server\WxxcxLogin;
use app\common\server\user\UserServer;

class Login extends ApiBase {

    public function _initialize() {
        parent::_initialize();
    }

    /**
     * 小程序code请求接口
     * @param code 小程序用户code --必传
     * @param xcx_store_id  门店id
     * @param encryptedData  加密数据
     * @param iv  加密算法的初始向量 详见https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/signature.html
     */
    public function wxXcxLogin() {
        exit;
        if (IS_POST) {
            $data = input('post.');
            $xcxLogin = new WxxcxLogin($data);
            $user_login = $xcxLogin->getXcxUserInfo();
            $user_login['xcx_store_id'] = $data['xcx_store_id'];
            $result = $this->_wxxcx->xcxUserUpdate($user_login);
            if ($result) {
                $this->apiSuccess($result);
            } else {
                $this->apiError('添加用户信息失败');
            }
        }
    }

    /*
     * app---微信授权登陆
     * @param code --微信授权登陆码 --必传
     */

    public function appWxLogin() {
        $this->wxlogin();
    }
    /*
     * 一键登陆--新颜
     */
    public function oneKeyLogin()
    {
        $post['platform'] = $this->platform;
        $post['app_version'] = $this->version;
        $post['ocl_token'] = $this->des_data['ocl_token'];
        if(empty($post['ocl_token'])){
             $this->apiError('请传token');
        }
        $xinyan=new \org\Xinyan();
        $xinyan_res=$xinyan->getMobile($post['ocl_token']);
        if(!$xinyan_res['success']){
             $this->apiError('一键登录失败'); 
        }else{
            $post['tel']=$xinyan_res['result']['phoneNum'];
        }
        $userSer = new UserServer();
        $login = $userSer->oneKeyLogin($post);
        if ($login['code'] == 1000) {
            $this->apiSuccess($login['data'], $login['msg']);
        } else {
            $this->apiError($login['msg']);
        }
    }
    /*
     * 一键登陆--创蓝
     */
    public function oneKeyLoginCl(){
        $post = $this->des_data;
        $post['platform'] = $this->platform;
        $post['app_version'] = $this->version;
        $post['umeng_device'] = $this->umeng_device;
        $post['imei'] = $this->imei;
        $post['check_type'] = 3;

        $params = [
            'appId' => $post['appId'], // 当前APP对应的appid,SDK传入
            'accessToken' => $post['accessToken'], // 运营商token,SDK传入
            'telecom' => $post['telecom'], // 运营商，SDK传入
            'timestamp' => $post['timestamp'], // UNIX时间戳，毫秒级，SDK传入
            'randoms' => $post['randoms'], // 随机数，SDK传入
            'device' => $post['cl_device'], // 设备型号，SDK传入
            'sign' => $post['sign'], // 签名，SDK传入
            'version' => $post['cl_version'], // SDK版本号，SDK传入
        ];
        $chuanglan = new \org\Sanyan();
        $xinyan_res = $chuanglan->getMobile($params, $this->platform);
        if (!$xinyan_res['success']) {
            return $this->apiError('一键登录失败');
        } else {
            $post['tel'] = $xinyan_res['tel'];
        }
        $userSer = new UserServer();
        $login = $userSer->oneKeyLogin($post);
        if ($login['code'] == 1000) {
            $this->apiSuccess($login['data'], $login['msg']);
        } else {
            $this->apiError($login['msg']);
        }
    }
    /*
     * 用户登陆
     * 请求地址
     * @param mobile 手机
     * @param password 密码
     * @param type 1:密码登陆 2:短信登陆
     * @param sms_code 验证码
     */

    public function login() {
        if ($this->request->isPost()) {
            $user_server = new UserServer();
            $result = $user_server->loginInApp($this->des_data);
            if ($result['code'] == 1000) {
                $this->apiSuccess($result['data'], $result['msg']);
            } else {
                $this->apiError($result['msg']);
            }
        }
    }

    /*
     * 忘记密码
     * @param mobile 手机号
     * @param step 1：验证手机号 2：全部数据提交
     * @param password 新密码
     * @param password_again 再一次密码
     * @param sms_code 短信验证码
     */

    public function forgetPwd() {
        if ($this->request->isPost()) {
            if ($this->des_data['step'] == 1) {
                $res = Db::name('user')->where('mobile=' . $this->des_data['mobile'])->find();
                if (empty($res)) {
                    $this->apiError('手机号不存在');
                } else {
                    $this->apiSuccess(1, "手机号码存在！");
                }
            } else {
                $user_server = new UserServer();
                $result = $user_server->forgetPwdApp($this->des_data);
                if ($result['code'] == 1000) {
                    $this->apiSuccess($result, $result['msg']);
                } else {
                    $this->apiError($result['msg']);
                }
            }
        }
    }

}
