<?php

namespace app\api\controller\V2;

use app\common\controller\ApiBase;

/**
 * @author wuningwen
 */
class Article extends ApiBase {
    /*
     * 常见问题
     */

    public function problem() {
        if ($this->des_data['type'] == 1) {
            $list['lqb'] = 'wap/#/allQues';
            $list['lqbdq'] = 'wap/#/dingQues';
            $list['tyj'] = 'wap/#/OjgQues';
            $list['cz'] = 'wap/#/wtQues';
            $list['tx'] = 'wap/#/reQues';
            $list['yhk'] = 'wap/#/savQues';
            $list['gysl'] = 'wap/#/about';
            $list['ydgw'] = 'wap/#/website';
            $list['ydjf'] = 'wap/#/yindie';
            $list['gsjs'] = 'wap/#/referral';
            $list['bbjs'] = 'wap/#/introduction';
            $list['weixin'] = 'wap/#/weixin';
            $list['weibo'] = 'wap/#/none';
            $list['mtbd'] = 'wap/#/none';
            $list['gszz'] = 'wap/#/none';
            $list['aqbz'] = 'wap/#/safety';
        } else {
             $list['lqb'] = 'wap/#/allQues';
            $list['lqbdq'] = 'wap/#/dingQues';
            $list['tyj'] = 'wap/#/OjgQues';
            $list['cz'] = 'wap/#/wtQues';
            $list['tx'] = 'wap/#/reQues';
        }


        $this->apiSuccess($list);
    }

    public function pl() {
        $list['lqb'] = 'wap/#/allQues';
        $list['lqbdq'] = 'wap/#/dingQues';
        $list['tyj'] = 'wap/#/OjgQues';
        $list['cz'] = 'wap/#/wtQues';
        $list['tx'] = 'wap/#/reQues';
        $list['yhk'] = 'wap/#/savQues';
        $list['gysl'] = 'wap/#/about';
        $list['ydgw'] = 'wap/#/website';
        $list['ydjf'] = 'wap/#/yindie';
        $list['gsjs'] = 'wap/#/referral';
        $list['bbjs'] = 'wap/#/introduction';
        $list['weixin'] = 'wap/#/weixin';
        $list['weibo'] = 'wap/#/none';
        $list['mtbd'] = 'wap/#/none';
        $list['gszz'] = 'wap/#/none';
        $list['aqbz'] = 'wap/#/safety';

        $this->apiSuccess($list);
    }

}
