<?php
namespace app\admin\controller;

use app\common\controller\AdminBase;

/**
 * 用户购车资料
 * Class UserCarInfo
 * @package app\admin\controller
 */
class UserCarInfo extends AdminBase
{

    /**
     * 购车资料列表
     */
    public function index(){
        $username=input('username');
        $tel=input('tel');
        $type=input('car_type');
        $where=[];
        if ($username) {
            $where['username'] = ['like', "%" . $username . "%"];
        }
        if ($tel) {
            $where['tel'] = ['=',$tel];
        }

        if(isset($type) && $type!=''){
            $where['car_type']=['=',$type];
        }
        $map=['username'=>$username,'car_type'=>$type,'tel'=>$tel];
        $list = db('user_car_info')->alias('c')
            ->join(config('database.prefix').'zone z','c.city_id = z.zone_id','left')
            ->field('c.*,z.zone_name')
            ->where($where)->order('id desc')->paginate(15, false, ['query' => $map]);

        return $this->fetch('index', ['list' => $list,'map'=>$map]);

    }

    public function check($id){
        $carInfo = db('user_car_info')->alias('c')
            ->join(config('database.prefix').'zone z','c.city_id = z.zone_id','left')
            ->field('c.*,z.zone_name')
            ->find();
        return $this->fetch('check', ['carInfo' => $carInfo]);
    }

    /**
     * 删除
     * @param $id
     */
    public function delete($id)
    {

        if (db('user_car_info')->where('id',$id)->delete()) {
            $this->success('删除成功');
        } else {
            $this->error('删除失败');
        }
    }

}