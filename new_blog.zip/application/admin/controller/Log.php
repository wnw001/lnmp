<?php

namespace app\admin\controller;

use app\common\model\ActionLog as ActionLogModel;
use app\common\controller\AdminBase;
use think\Db;
use think\Session;

/**
 * 操作日志
 */
class Log extends AdminBase {

    protected $action_log_model;

    protected function _initialize() {
        parent::_initialize();
        $this->action_log_model = new ActionLogModel();
    }

    /**
     * oa模块---增删改操作日志
     */
    public function index($uid = '', $action = '', $page = 1) {
        $where = [];
        $field = '*';
        if (!empty($uid)) {
            $where['uid'] = $uid;
        }
        if (!empty($action)) {
            $where['action'] = ['like', "%$action%"];
        }
        $action_log = $this->action_log_model->field($field)->where($where)->order(['create_time' => 'DESC'])->paginate(10, false, ['page' => $page]);
        foreach ($action_log as $key => $value) {
            $res_user[$key] = Db::name('admin_user')->where('id='.$value['uid'])->find();
            $action_log[$key]['real_name'] = $res_user[$key]['real_name'];
        }

        return $this->fetch('index', ['action_log' => $action_log,'uid'=>$uid,'action'=>$action]);
    }

    /**
     * 添加
     * @return mixed
     */
    public function add() {
        $res_ptyg = Db::name('auth_group_access')->where('group_id=4')->select();
        $res_memeber = Db::name('offer_member')->where('status=1')->select();

        foreach ($res_memeber as $key => $value) {
            $p_uid_array[$key] = $value['p_uid'];
        }
        foreach ($res_ptyg as $key => $value) {
            if (!in_array($value['uid'], $p_uid_array)) {
                $res_admin_user[$key] = Db::name('admin_user')->where('id=' . $value['uid'])->find();
            }
        }

        return $this->fetch('add', ['res_admin_user' => $res_admin_user]);
    }

    /**
     * 保存
     */
    public function save() {
        if ($this->request->isPost()) {
            $data = $this->request->param();

            $data_s['create_time'] = time();
            $data_s['p_uid'] = $data['uid'];
            $data_s['uid'] = Session::get('admin_id');
            $data_s['gruop_id'] = 5;
            $res = Db::name('offer_member')->insertGetId($data_s);
            if ($res) {
                $this->success('保存成功', '/admin/member/index');
            } else {
                $this->error('保存失败', '/admin/member/index');
            }
        }
    }

    /**
     * 编辑
     * @param $id
     * @return mixed
     */
    public function edit($id) {
        $customer = $this->action_log_model->find($id);
        $customer['data'] = unserialize($customer['data']);
        dump($customer['data']);exit;
        return $this->fetch('edit', ['customer' => $customer]);
    }

    /**
     * 更新
     * @param $id
     */
    public function update($id) {
        if ($this->request->isPost()) {
            $data = $this->request->param();
            $validate_result = $this->validate($data, 'Link');

            if ($validate_result !== true) {
                $this->error($validate_result);
            } else {
                $data['update_time'] = time();
                if ($this->Customer_model->allowField(true)->save($data, $id) !== false) {
                    $this->success('更新成功', '/admin/customer/index');
                } else {
                    $this->error('更新失败', '/admin/customer/index');
                }
            }
        }
    }

    /**
     * 删除友情链接
     * @param $id
     */
    public function delete($id) {
        if (Db::name('offer_member')->where('id=' . $id)->delete()) {
            $this->success('删除成功', '/admin/member/index');
        } else {
            $this->error('删除失败', '/admin/member/index');
        }
    }

}
