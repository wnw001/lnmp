<?php

namespace app\admin\controller;

use app\common\controller\AdminBase;
use think\Db;

/**
 * 后台首页
 * Class Index
 * @package app\admin\controller
 */
class Index extends AdminBase {

    protected function _initialize() {
        parent::_initialize();
    }

    /**
     * 首页
     * @return mixed
     */
    public function index() {
        $version = Db::query('SELECT VERSION() AS ver');
        $config = [
            'url' => $_SERVER['HTTP_HOST'],
            'document_root' => $_SERVER['DOCUMENT_ROOT'],
            'server_os' => PHP_OS,
            'server_port' => $_SERVER['SERVER_PORT'],
            'server_soft' => $_SERVER['SERVER_SOFTWARE'],
            'php_version' => PHP_VERSION,
            'mysql_version' => $version[0]['ver'],
            'max_upload_size' => ini_get('upload_max_filesize')
        ];

        return $this->fetch('index', ['config' => $config]);
    }

    /*
     * 首页车广告
     */

    public function carRecommend() {
        $res_car = Db::name('car_recommend')->select();
        return $this->fetch('car_recommend', ['res_car' => $res_car]);
    }

    /*
     * 添加
     */

    public function carRecommendAdd() {
        if (request()->isPost()) {
            $data = $this->request->post();
            if(!isset($data['video_url'])){ $this->error("请先上传图片！");}
            $data['image_url'] = $data['video_url'][0];
            unset($data['video_url']);
            unset($data['myradio']);
            $data['c_time'] = time();
            $result = Db::name('car_recommend')->insertGetId($data);
            if ($result) {
                $this->success('更新成功', 'index/carRecommend');
            } else {
                $this->error('更新失败', 'index/carRecommend');
            }
        }
        return $this->fetch('car_recommend_add');
    }
    /*
     * 编辑
     */
    public function car_recommend_eidt($id) {
        if (request()->isPost()) {
            $data = $this->request->post();
            if(!isset($data['video_url'])){ $this->error("请先上传图片！");}
            $data['image_url'] = $data['video_url'][0];
            unset($data['video_url']);
            unset($data['myradio']);
            $data['u_time'] = time();
            $result = Db::name('car_recommend')->where('id='.$data['id'])->update($data);
            if ($result) {
                $this->success('更新成功', 'index/carRecommend');
            } else {
                $this->error('更新失败', 'index/carRecommend');
            }
        }
        $res = Db::name('car_recommend')->where('id='.$id)->find();
        return $this->fetch('car_recommend_edit',['res'=>$res]);
    }
    /*
     * 删除
     */
    public function carRecommendDelete($id){
        if(Db::name('car_recommend')->delete($id)){
            $this->success('删除成功！');
        }else{
            $this->error('删除失败！');
        }
    }
}
