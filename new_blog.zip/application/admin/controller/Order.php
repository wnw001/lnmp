<?php

namespace app\admin\controller;

use app\common\controller\AdminBase;
use app\common\model\PayOrder as PayOrderModel;
use think\Db;

class Order extends AdminBase {

    protected $model;

    protected function _initialize() {
        parent::_initialize();
        $this->model = new PayOrderModel();
    }

    /**
     * 订单列表
     * @return mixed
     */
    public function index($pay_type='',$order_status='',$order_sn='',$page = 1) {
        $map = [];
        $where =[];
        if ($order_sn) {
            $where['order_sn'] = $order_sn;            
        }
        $map['order_sn'] = $order_sn;
        if ($pay_type) {
            $where['pay_type'] = $pay_type;            
        }
        $map['pay_type'] = $pay_type;
        if ($order_status) {
            $where['order_status'] = $order_status;            
        }
        $map['order_status'] = $order_status;
        $map['page'] = $page;
        $query_criteria = Db::name('query_criteria')->find();
        $query_criteria_oil_type = json_decode($query_criteria['oil_type'],true);
        $array = array_merge(array_merge($query_criteria_oil_type['qiyou'],$query_criteria_oil_type['caiyou']),$query_criteria_oil_type['tianranqi']);
        $order_list = $this->model->where($where)->order('id desc')->paginate(15, false, ['query' => $map]);
        foreach ($order_list as $key => $value) {
            $user_list[$key] = Db::name('user')->where('id='.$value['uid'])->field('id,username,mobile')->find();
            $gas_list[$key] = Db::name('gas_station')->where('id='.$value['gas_id'])->field('id,name')->find();
            $gas_goods_list[$key] = Db::name('gas_station_goods')->where('id='.$value['goods_id'])->find();
            if($gas_goods_list[$key]){
                $order_list[$key]['type_name']= $array[$gas_goods_list[$key]['type']-1];
            }else{
                $order_list[$key]['type_name'] = '数据不存在';
            }
            $order_list[$key]['username']= $user_list[$key]['username'];
            $order_list[$key]['gas_name']= $gas_list[$key]['name'];
            $order_list[$key]['goods_type']= $gas_goods_list[$key]['goods_type'];
            $order_list[$key]['market_value']= $gas_goods_list[$key]['market_value'];
            $order_list[$key]['gas_value']= $gas_goods_list[$key]['gas_value'];
        }
        return $this->fetch('index', ['order_list' => $order_list, 'map' => $map]);
    }
    /*
     * 添加
     */
    public function add(){
        return $this->fetch('add');
    }
    /*
     * 保存
     */
    public function save(){
        if ($this->request->isPost()) {
            $data = $this->request->param();
            $data['c_time'] = time();
            if(Db::name('gas_station_impression')->insertGetId($data)){
                 $this->success('更新成功','gas_station_impression/index');
            } else {
                $this->error('更新失败','gas_station_impression/index');
            }       
    }
    }
    /**
     * 编辑印象
     * @param $id
     * @return mixed
     */
    public function edit($id) {
        $gas_station_im_list = $this->model->find($id);
        return $this->fetch('edit', ['list' => $gas_station_im_list]);
    }

    /*
     * 更新加油站
     * @param $id
     */

    public function update() {
        if ($this->request->isPost()) {
            $data = $this->request->param();
            $data['u_time'] = time();
            if(Db::name('gas_station_impression')->where('id='.$data['id'])->update($data)){
                 $this->success('更新成功','gas_station_impression/index');
            } else {
                $this->error('更新失败','gas_station_impression/index');
            }       
    }
    }

    /**
     * 删除加油站
     * @param $id
     */
    public function delete($id) {
        if ($this->model->destroy($id)) {
            $this->success('删除成功');
        } else {
            $this->error('删除失败');
        }
    }

}
