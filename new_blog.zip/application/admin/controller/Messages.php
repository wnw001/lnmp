<?php

namespace app\admin\controller;

use app\common\controller\AdminBase;
use app\common\model\Messages as MesModel;

class Messages extends AdminBase
{

    /**
     * 消息列表
     */
    public function index(){
        $title=input('msg_title');
        $type=input('type');
        $where=[];
        if ($title) {
            $where['msg_title'] = ['like', "%" . $title . "%"];
        }
        if(isset($type) && $type!=''){
            $where['type']=['=',$type];
        }
        $map=['msg_title'=>$title,'type'=>$type];
        $mes_list = db('messages')->alias('m')
            ->join(config('database.prefix').'user u','m.uid = u.id','left')
            ->field('m.*,u.username')
            ->where($where)->order('id desc')->paginate(15, false, ['query' => $map]);

        return $this->fetch('index', ['mes_list' => $mes_list,'map'=>$map]);

    }

    /**
     * 查看消息详情
     * @param $id
     */
    public function check($id){
        $msg= db('messages')->alias('m')
            ->join(config('database.prefix').'user u','m.uid = u.id','left')
            ->field('m.*,u.username')
            ->where('m.id',$id)
            ->find();

        return $this->fetch('check', ['msg' => $msg]);
    }

    /**
     * 消息的添加
     * @return mixed
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */

    public function add()
    {
        if(request()->isPost()) {
            $data = input('post.');
            $data['c_time'] = time();
            $res = db('messages')->insert($data);
            if ($res > 0) {
                $this->success('添加成功', 'Messages/index');
            } else {
                $this->error('添加失败', 'Messages/index');
            }
        }else{
            $userList=db('user')->where('status',1)->select();
            $this->assign('user_list',$userList);
            return $this->fetch('add');
        }

    }

    /**
     *消息的编辑
     * @param $id
     * @return mixed
     * @throws \think\Exception
     */
    public function edit($id){
        if(request()->isPost()){
            $data=input('post.');
            $data['u_time']=time();
            $res=db('messages')->where('id',$id)->update($data);
            if ($res !==false) {
                $this->success('编辑成功', 'Messages/index');
            } else {
                $this->error('编辑失败', 'Messages/index');
            }
        }else{
            $msg= db('messages')->alias('m')
                ->join(config('database.prefix').'user u','m.uid = u.id','left')
                ->field('m.*,u.username')
                ->where('m.id',$id)
                ->find();
            $userList=db('user')->where('status',1)->select();
            $this->assign('user_list',$userList);
            return $this->fetch('edit', ['msg' => $msg]);

        }

    }



    /**
     * 删除消息
     * @param $id
     */
    public function delete($id)
    {
        if (db('messages')->where('id',$id)->delete()) {
            $this->success('删除成功');
        } else {
            $this->error('删除失败');
        }
    }

}