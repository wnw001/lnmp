<?php

namespace app\admin\controller;

use app\common\model\Config as ConfigModel;
use app\common\controller\AdminBase;
use think\Db;
/**
 * 第三方配置管理
 * Class Article
 * @package app\admin\controller
 */
class Config extends AdminBase {

    protected $config_model;

    protected function _initialize() {
        parent::_initialize();
        $this->config_model = new ConfigModel();
    }

    /**
     * 文章管理
     * @param int    $cid     分类ID
     * @param string $keyword 关键词
     * @param int    $page
     * @return mixed
     */
    public function index($page = 1) {
        $map = [];
        $field = 'id,key_name,value,mark';

        $config_list = $this->config_model->field($field)->where($map)->paginate(15, false, ['page' => $page]);
        return $this->fetch('index', ['config_list' => $config_list]);
    }

    /**
     * 添加文章
     * @return mixed
     */
    public function add() {
        return $this->fetch();
    }

    /**
     * 保存文章
     */
    public function save() {
        if ($this->request->isPost()) {
            $data = $this->request->param();
            $validate_result = $this->validate($data, 'Config');

            if ($validate_result !== true) {
                $this->error($validate_result);
            } else {
                if ($this->config_model->allowField(true)->save($data)) {
                    $this->success('保存成功', '/admin/config/index');
                } else {
                    $this->error('保存失败', '/admin/config/index');
                }
            }
        }
    }

    /**
     * 编辑文章
     * @param $id
     * @return mixed
     */
    public function edit($id) {
        $config = $this->config_model->find($id);

        return $this->fetch('edit', ['config' => $config]);
    }

    /**
     * 更新文章
     * @param $id
     */
    public function update($id) {
        if ($this->request->isPost()) {
            $data = $this->request->param();
            $validate_result = $this->validate($data, 'Config');

            if ($validate_result !== true) {
                $this->error($validate_result);
            } else {
                if ($this->config_model->allowField(true)->save($data, $id) !== false) {
                    $res_config = Db::name('config')->select();
                    $value = $res_config[0]['value'] . ',' . $res_config[1]['value'] . ',' . $res_config[2]['value'] .
                            ',' . $res_config[3]['value'] . ',' . $res_config[4]['value'] . ',' . $res_config[5]['value'];
                    file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/application/aliyun.txt', $value);
                    $result = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/application/aliyun.txt');                                       
                    $file = file_get_contents($_SERVER['DOCUMENT_ROOT'] . "/application/aliyun_model.php");
                    $file = str_replace('aliyun_accessKeyId', $res_config[1]['value'], $file);
                    $file = str_replace('aliyun_accessKeySecret', $res_config[2]['value'], $file);
                    $file = str_replace('aliyun_endpoint', $res_config[3]['value'], $file);
                    $file = str_replace('aliyun_bucket', $res_config[4]['value'], $file);
                    $file = str_replace('aliyun_site_img_url', $res_config[5]['value'], $file);
                    $file = str_replace('web_url', $res_config[0]['value'], $file);
                    file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/application/aliyun.php', $file);
                    $this->success('更新成功', '/admin/config/index');
                } else {
                    $this->error('更新失败', '/admin/config/index');
                }
            }
        }
    }

    /**
     * 删除文章
     * @param int   $id
     * @param array $ids
     */
    public function delete($id = 0, $ids = []) {
        $id = $ids ? $ids : $id;
        if ($id) {
            if ($this->config_model->destroy($id)) {
                $this->success('删除成功');
            } else {
                $this->error('删除失败');
            }
        } else {
            $this->error('请选择需要删除的文章');
        }
    }

    /**
     * 文章审核状态切换
     * @param array  $ids
     * @param string $type 操作类型
     */
    public function toggle($ids = [], $type = '') {
        $data = [];
        $status = $type == 'audit' ? 1 : 0;

        if (!empty($ids)) {
            foreach ($ids as $value) {
                $data[] = ['id' => $value, 'status' => $status];
            }
            if ($this->config_model->saveAll($data)) {
                $this->success('操作成功');
            } else {
                $this->error('操作失败');
            }
        } else {
            $this->error('请选择需要操作的文章');
        }
    }

}
