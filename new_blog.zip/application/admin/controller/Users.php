<?php
namespace app\admin\controller;

use app\common\controller\AdminBase;
use app\common\model\User;
use app\common\model\User as UserModel;

class Users extends AdminBase{

    protected $user_model;

    protected function _initialize()
    {
        parent::_initialize();
        $this->user_model = new UserModel();
    }
    /**
     * 用户列表
     */
    public function index(){

        $username=trim(input('username'));//用户名
        $mobile=trim(input('mobile'));//手机号
        $start_time = input('start_time');//创建的开始时间
        $end_time = input('end_time');//创建的结束时间
        $where=[];
        if ($username) {
            $where['username'] = ['like', "%" . $username . "%"];
        }
        if ($mobile) {
            $where['mobile'] = ['like', "%" . $mobile . "%"];
        }
        if ($start_time && $end_time) {
            $where['create_time'] = ['BETWEEN', [ strtotime($start_time), strtotime($end_time)]];
        }
        $map=['username'=>$username,'mobile'=>$mobile,'start_time'=>$start_time,'end_time'=>$end_time];
        $user_list= $this->user_model->where($where)->order('id desc')->paginate(15, false, ['query' => $map]);
        return $this->fetch('index',['user_list'=>$user_list,'map'=>$map]);
    }

    public function edit($id){

        if(request()->isPost()){
            $data            = $this->request->post();
            $user           = $this->user_model->find($id);
            $user->id       = $id;
            $user->status   = $data['status'];
            if ($user->save() !== false) {
                $this->success('更新成功','Users/index');
            } else {
                $this->error('更新失败');
            }
        }else{
            $user           = $this->user_model->find($id);
            return $this->fetch('edit',['user'=>$user]);
        }
    }

}