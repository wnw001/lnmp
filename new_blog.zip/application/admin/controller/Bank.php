<?php
namespace app\admin\controller;

use app\common\controller\AdminBase;

class Bank extends AdminBase
{
    public function index(){
        $name=input('name');
        $where=[];
        if ($name) {
            $where['name'] = ['like', "%" . $name . "%"];
        }
        $map=['name'=>$name];
        $bank_list = db('bank')
            ->where($where)->order('sort desc')->paginate(15, false, ['query' => $map]);
        return $this->fetch('index', ['bank_list' => $bank_list,'map'=>$map]);
    }

    /**
     * 消息的添加
     * @return mixed
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */

    public function add()
    {
        if(request()->isPost()) {
            $data = input('post.');
            $data['c_time'] = time();
            $res = db('bank')->insert($data);
            if ($res > 0) {
                $this->success('添加成功', 'Bank/index');
            } else {
                $this->error('添加失败', 'Bank/index');
            }
        }else{
            return $this->fetch('add');
        }

    }

    /**
     *银行的编辑
     * @param $id
     * @return mixed
     * @throws \think\Exception
     */
    public function edit($id){
        if(request()->isPost()){
            $data=input('post.');
            $res=db('bank')->where('id',$id)->update($data);
            if ($res !==false) {
                $this->success('编辑成功', 'Bank/index');
            } else {
                $this->error('编辑失败');
            }
        }else{
            $bank= db('bank')->where('id',$id)->find();
            return $this->fetch('edit', ['bank' => $bank]);
        }

    }



    /**
     * 删除银行
     * @param $id
     */
    public function delete($id)
    {

        if (db('bank')->where('id',$id)->delete()) {
            $this->success('删除成功');
        } else {
            $this->error('删除失败');
        }
    }

}