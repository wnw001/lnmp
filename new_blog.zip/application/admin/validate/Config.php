<?php
namespace app\admin\validate;

use think\Validate;

/**
 * Class config
 * @package app\admin\validate
 */
class Config extends Validate
{

}