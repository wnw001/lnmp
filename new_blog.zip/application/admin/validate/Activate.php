<?php
namespace app\admin\validate;

use think\Validate;

class Activate extends Validate
{

}