<?php

use think\Db;
use think\Config;

/**
 * 获取分类所有子分类
 * @param int $cid 分类ID
 * @return array|bool
 */
function get_category_children($cid) {
    if (empty($cid)) {
        return false;
    }

    $children = Db::name('category')->where(['path' => ['like', "%,{$cid},%"]])->select();

    return array2tree($children);
}

//过滤html代码
function clear_html_label($html) {
    $search = array("'<script[^>]*?>.*?</script>'si", "'<[/!]*?[^<>]*?>'si", "'([rn])[s]+'", "'&(quot|#34);'i", "'&(amp|#38);'i", "'&(lt|#60);'i", "'&(gt|#62);'i", "'&(nbsp|#160);'i", "'&(iexcl|#161);'i", "'&(cent|#162);'i", "'&(pound|#163);'i", "'&(copy|#169);'i", "'&#(d+);'e");
    $replace = array("", "", "1", "", "&", "<", ">", " ", chr(161), chr(162), chr(163), chr(169), "chr(1)");

    return preg_replace($search, $replace, $html);
}

/**
 * 根据分类ID获取文章列表（包括子分类）
 * @param int   $cid   分类ID
 * @param int   $limit 显示条数
 * @param array $where 查询条件
 * @param array $order 排序
 * @param array $filed 查询字段
 * @return bool|false|PDOStatement|string|\think\Collection
 */
function get_articles_by_cid($cid, $limit = 10, $where = [], $order = [], $filed = []) {
    if (empty($cid)) {
        return false;
    }

    $ids = Db::name('category')->where(['path' => ['like', "%,{$cid},%"]])->column('id');
    $ids = (!empty($ids) && is_array($ids)) ? implode(',', $ids) . ',' . $cid : $cid;

    $fileds = array_merge(['id', 'cid', 'title', 'introduction', 'thumb', 'reading', 'publish_time'], (array) $filed);
    $map = array_merge(['cid' => ['IN', $ids], 'status' => 1, 'publish_time' => ['<= time', date('Y-m-d H:i:s')]], (array) $where);
    $sort = array_merge(['is_top' => 'DESC', 'sort' => 'DESC', 'publish_time' => 'DESC'], (array) $order);

    $article_list = Db::name('article')->where($map)->field($fileds)->order($sort)->limit($limit)->select();

    return $article_list;
}

/**
 * 根据分类ID获取文章列表，带分页（包括子分类）
 * @param int   $cid       分类ID
 * @param int   $page_size 每页显示条数
 * @param array $where     查询条件
 * @param array $order     排序
 * @param array $filed     查询字段
 * @return bool|\think\paginator\Collection
 */
function get_articles_by_cid_paged($cid, $page_size = 15, $where = [], $order = [], $filed = []) {
    if (empty($cid)) {
        return false;
    }

    $ids = Db::name('category')->where(['path' => ['like', "%,{$cid},%"]])->column('id');
    $ids = (!empty($ids) && is_array($ids)) ? implode(',', $ids) . ',' . $cid : $cid;

    $fileds = array_merge(['id', 'cid', 'title', 'introduction', 'thumb', 'reading', 'publish_time'], (array) $filed);
    $map = array_merge(['cid' => ['IN', $ids], 'status' => 1, 'publish_time' => ['<= time', date('Y-m-d H:i:s')]], (array) $where);
    $sort = array_merge(['is_top' => 'DESC', 'sort' => 'DESC', 'publish_time' => 'DESC'], (array) $order);

    $article_list = Db::name('article')->where($map)->field($fileds)->order($sort)->paginate($page_size);

    return $article_list;
}

/**
 * 数组层级缩进转换
 * @param array $array 源数组
 * @param int   $pid
 * @param int   $level
 * @return array
 */
function array2level($array, $pid = 0, $level = 1) {
    static $list = [];
    foreach ($array as $v) {
        if ($v['pid'] == $pid) {
            $v['level'] = $level;
            $list[] = $v;
            array2level($array, $v['id'], $level + 1);
        }
    }

    return $list;
}

/**
 * 构建层级（树状）数组
 * @param array  $array          要进行处理的一维数组，经过该函数处理后，该数组自动转为树状数组
 * @param string $pid_name       父级ID的字段名
 * @param string $child_key_name 子元素键名
 * @return array|bool
 */
function array2tree(&$array, $pid_name = 'pid', $child_key_name = 'children') {
    $counter = array_children_count($array, $pid_name);
    if (!isset($counter[0]) || $counter[0] == 0) {
        return $array;
    }
    $tree = [];
    while (isset($counter[0]) && $counter[0] > 0) {
        $temp = array_shift($array);
        if (isset($counter[$temp['id']]) && $counter[$temp['id']] > 0) {
            array_push($array, $temp);
        } else {
            if ($temp[$pid_name] == 0) {
                $tree[] = $temp;
            } else {
                $array = array_child_append($array, $temp[$pid_name], $temp, $child_key_name);
            }
        }
        $counter = array_children_count($array, $pid_name);
    }

    return $tree;
}

/**
 * 子元素计数器
 * @param array $array
 * @param int   $pid
 * @return array
 */
function array_children_count($array, $pid) {
    $counter = [];
    foreach ($array as $item) {
        $count = isset($counter[$item[$pid]]) ? $counter[$item[$pid]] : 0;
        $count++;
        $counter[$item[$pid]] = $count;
    }

    return $counter;
}

/**
 * 把元素插入到对应的父元素$child_key_name字段
 * @param        $parent
 * @param        $pid
 * @param        $child
 * @param string $child_key_name 子元素键名
 * @return mixed
 */
function array_child_append($parent, $pid, $child, $child_key_name) {
    foreach ($parent as &$item) {
        if ($item['id'] == $pid) {
            if (!isset($item[$child_key_name]))
                $item[$child_key_name] = [];
            $item[$child_key_name][] = $child;
        }
    }

    return $parent;
}

/**
 * 循环删除目录和文件
 * @param string $dir_name
 * @return bool
 */
function delete_dir_file($dir_name) {
    $result = false;
    if (is_dir($dir_name)) {
        if ($handle = opendir($dir_name)) {
            while (false !== ($item = readdir($handle))) {
                if ($item != '.' && $item != '..') {
                    if (is_dir($dir_name . DS . $item)) {
                        delete_dir_file($dir_name . DS . $item);
                    } else {
                        unlink($dir_name . DS . $item);
                    }
                }
            }
            closedir($handle);
            if (rmdir($dir_name)) {
                $result = true;
            }
        }
    }

    return $result;
}

/**
 * 判断是否为手机访问
 * @return  boolean
 */
function is_mobile() {
    static $is_mobile;

    if (isset($is_mobile)) {
        return $is_mobile;
    }

    if (empty($_SERVER['HTTP_USER_AGENT'])) {
        $is_mobile = false;
    } elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false
    ) {
        $is_mobile = true;
    } else {
        $is_mobile = false;
    }

    return $is_mobile;
}

/**
 * 手机号格式检查
 * @param string $mobile
 * @return bool
 */
function check_mobile_number($mobile) {
    if (!is_numeric($mobile)) {
        return false;
    }
    $reg = '#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#';

    return preg_match($reg, $mobile) ? true : false;
}

/**
 * 公共返回数据
 * @param string $msg
 * @param int $code 1001失败 1000成功
 * @param array $data
 */
function returnPubData($msg = '数据请求失败', $code = '1001', $data = [], $url_code = 0) {
    $data_arr = [
        'code' => $code,
        'data' => $data,
        'msg' => $msg,
        'url_code' => $url_code,
    ];
    return $data_arr;
}

/**
 * 判断手机号码格式是否正确
 * @param $mobilephone
 */
function is_mobilephone($mobilephone) {
    return strlen($mobilephone) == 11 && preg_match("/^13[0-9]{1}[0-9]{8}$|14[0-9]{1}[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8}|17[0-9]{1}[0-9]{8}$/", $mobilephone);
}

/**
 * 生成/验证【图片/短信】验证码
 *
 * @param string $code_session_key 验证码生成的session key【必填】
 * @param int $type 1图片验证码 2短信验证码
 * @param int $act 1生成 2验证
 * @param bool $reset true 验证成功重置session， false不重置
 * @param array $param
 */
function verifycode($code_session_key, $type = 1, $act = 1, $param = [], $reset = true) {
    if (!$code_session_key) {
        return;
    }
    $vcode = new \org\Verify(['reset' => $reset]);
//    $vcode = new \org\Verify(['reset' => $reset, 'fontttf' => '5.ttf', 'fontSize' => 28]);
    //验证验证码
    if ($act == 2) {
        if (!$param['verify_code']) {
            return false;
        }
        if (\think\Config::get('SMS_DEBUG')) {
            if ($param['verify_code'] == 666666) {
                return true;
            }
        }
        $param['verify_id'] = isset($param['verify_id']) ? $param['verify_id'] : $code_session_key;
        if (!$vcode->check($param['verify_code'], $param['verify_id'])) {
            return false;
        }
        return true;
    } else {
        //生成验证码
        if ($type == 1) {//生成图片验证码
            $vcode->imageH = isset($param['width']) ? $param['width'] : 32;
            $vcode->imageW = isset($param['height']) ? $param['height'] : 100;
            if (isset($param['codeSet'])) {
                $vcode->codeSet = $param['codeSet'];
            }
            $vcode->length = isset($param['width']) ? $param['width'] : 4;
            $vcode->useNoise = isset($param['width']) ? $param['width'] : false;
            $vcode->fontSize = isset($param['width']) ? $param['width'] : 14;
            $param['verify_id'] = isset($param['verify_id']) ? $param['verify_id'] : $code_session_key;
            return $vcode->entry($param['verify_id']);
        } else {//生成短信验证码
            $data['sms_code'] = $vcode->smscode($code_session_key);
            $sess = $vcode->getSmsSession($code_session_key);
            $data['send_num'] = $sess['send_num'];  //发送次数
            return $data;
        }
    }
}

/**
 * 对象 转 数组
 *
 * @param object $obj 对象
 * @return array
 */
function object_to_array($obj) {
    $obj = (array) $obj;
    foreach ($obj as $k => $v) {
        if (gettype($v) == 'resource') {
            return;
        }
        if (gettype($v) == 'object' || gettype($v) == 'array') {
            $obj[$k] = (array) object_to_array($v);
        }
    }

    return $obj;
}

/**
 * 301跳转
 * @param type $url
 * @return boolean
 */
function header301($url) {
    if (empty($url)) {
        return false;
    }
    header('HTTP/1.1 301 Moved Permanently');
    header('Location:' . $url);
    exit;
}

function sendGet($url, $data = null) {
    if (!empty($data)) {
        $get_data = '';
        foreach ($data as $k => $v) {
            $get_data .= "{$k}={$v}&";
        }
        $get_data = trim($get_data, '&');
    }
    if (!empty($get_data)) {
        $url .= '?' . $get_data;
    }
    $result = file_get_contents($url);
    if (!empty($result)) {
        $json = strval($result);
        $result = json_decode(trim($json, chr(239) . chr(187) . chr(191)), true); //删除bom头
    }
    return $result;
}

/**
 * 获取客户端IP地址
 * @param integer $type 返回类型 0 返回IP地址 1 返回IPV4地址数字
 * @param boolean $adv 是否进行高级模式获取（有可能被伪装） 
 * @return mixed
 */
function get_client_ip($type = 0, $adv = false) {
    $type = $type ? 1 : 0;
    static $ip = NULL;
    if ($ip !== NULL)
        return $ip[$type];
    if ($adv) {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $pos = array_search('unknown', $arr);
            if (false !== $pos)
                unset($arr[$pos]);
            $ip = trim($arr[0]);
        }elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    // IP地址合法验证
    $long = sprintf("%u", ip2long($ip));
    $ip = $long ? array($ip, $long) : array('0.0.0.0', 0);
    return $ip[$type];
}

/**
 * 生成订单号
 * @return bool
 */
function build_order_no() {
    return date('ymd') . substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
}

function array_to_xml($data) {
    $xml = '';
    foreach ($data as $key => $val) {
        is_numeric($key) && $key = "set";
        $xml .= "<$key>";
        $xml .= (is_array($val) || is_object($val)) ? array_to_xml($val) : $val;
        list ($key, ) = explode(' ', $key);
        $xml .= "</$key>";
    }

    return '<xml>' . $xml . '</xml>';
}

/**
 * 自定义排序函数
 * @param $param1
 * @param $param2
 * @return 0(不移动) 1(正向调换顺序) -1(逆向调换顺序)
 */
function my_sort($param1, $param2) {
    if ($param1['value'] == $param2['value'])
        return 0;
    else
        return $param1['value'] > $param2['value'] ? 1 : -1;
}

/**
 * api错误返回给js
 * @param int $type 类型
 */
function apiErrorJs($msg, $url = '') {
    header('Content-Type:application/json;charset=utf-8');
    header("Access-Control-Allow-Origin:*");
    $ret['code'] = 1001;
    $ret['url'] = $url;
    $ret['msg'] = $msg;
    die(json_encode($ret));
}

/**
 * api成功返回给js
 * @param type $param 返回值
 * @return string
 */
function apiSuccessJs($param, $url, $msg = '') {
    header('Content-Type:application/json;charset=utf-8');
    header("Access-Control-Allow-Origin:*");
    $ret['code'] = 1000;
    $ret['url'] = $url;
    $ret['msg'] = $msg;
    $ret['data'] = $param;
    die(json_encode($ret));
}

/*
 * 根据商户或用户生成邀请码
 * 既然id是不会重复的数据，那么把id转换为36进制的字符串就好了。
 */

function createCode($userId) {
    static $sourceString = [
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
        'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l',
        'm', 'n', 'o', 'p', 'q', 'r',
        's', 't', 'u', 'v', 'w', 'x',
        'y', 'z'
    ];
    $num = $userId;
    $code = '';
    while ($num) {
        $mod = $num % 36;
        $num = (int) ($num / 36);
        $code = "{$sourceString[$mod]}{$code}"; //邀请码拼接
    }
    //判断code的长度
    if (empty($code[4]))
        str_pad($code, 5, '0', STR_PAD_LEFT); //长度不够拼接'0'

    return $code;
}

/*
 * php生成GUID
 * GUID在空间上和时间上具有唯一性，保证同一时间不同地方产生的数字不同。
 * 世界上的任何两台计算机都不会生成重复的 GUID 值。
 * 需要GUID的时候，可以完全由算法自动生成，不需要一个权威机构来管理。
 * GUID的长度固定，并且相对而言较短小，非常适合于排序、标识和存储。
 */

function getGuid() {
    $charid = strtoupper(md5(uniqid(mt_rand(), true)));

    $hyphen = chr(45); // "-"
    $uuid = substr($charid, 0, 8) . $hyphen
            . substr($charid, 8, 4) . $hyphen
            . substr($charid, 12, 4) . $hyphen
            . substr($charid, 16, 4) . $hyphen
            . substr($charid, 20, 12);
    return $uuid;
}

/*
 * php生成随机唯一邀请码/优惠码 固定长度
 */

function make_coupon_card() {
    $code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $rand = $code[rand(0, 25)]
            . strtoupper(dechex(date('m')))
            . date('d') . substr(time(), -5)
            . substr(microtime(), 2, 5)
            . sprintf('%02d', rand(0, 99));
    for (
    $a = md5($rand, true),
    $s = '0123456789ABCDEFGHIJKLMNOPQRSTUV',
    $d = '',
    $f = 0; $f < 8; $g = ord($a[$f]),
            $d .= $s[( $g ^ ord($a[$f + 8]) ) - $g & 0x1F],
            $f++
    )
        ;
    return $d;
}

/**
 * 生成随机字符串（数字字母小写）
 * @param string $lenth 长度
 * @return string 字符串
 */
function getRandomString($len, $chars = null) {
    if (is_null($chars)) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    }
    mt_srand(10000000 * (double) microtime());
    for ($i = 0, $str = '', $lc = strlen($chars) - 1; $i < $len; $i++) {
        $str .= $chars[mt_rand(0, $lc)];
    }
    return $str;
}

/*
 * 去重字符串
 */

function uniqueString($str) {
    $arr = explode(',', $str);
    $arr = array_unique($arr);
    $data = '';
    //使用foreach循环拼接也可以得到，得到的效果是一样的  
    foreach ($arr as $key => $value) {
        $data .= $value . ','; //拼接关键代码</span></strong>  
    }
    $data = trim($data, ',');
    return $data;
}

function is_weixin() {

    if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {

        return true;
    }

    return false;
}

/*
 * 生成商户二维码
 */

function twoCode($id, $business_id) {
    $imgurl = SITE_URL_M . '/order/pay?store_id=' . $id . '&business_id=' . $business_id; //图片链接数据
    $suiji = mt_rand(1, 999);
    $h_name = md5(time() . $suiji);
    $img = $id . $h_name . '.png'; //图片名称
    $img_path = 'Public/upload/twoCode/'; //图片路径
    $dir = $img_path . $img;
    if (!(is_dir($img_path)))
        mkdir($img_path, 0777, TRUE);
    include_once 'Application/Common/Common/twoCode/phpqrcode/phpqrcode.php';
    $img_erwei = \QRcode::png($imgurl, $dir);
    $upyun = new \Common\Common\util\UpYun(UPYUN_BUCKET, UPYUN_NAME, UPYUN_PWD);
    try {
        $fh = fopen($dir, 'rb');
        $rsp = $upyun->writeFile('/twoCode/' . $img, $fh, TRUE);   // 上传图片，自动创建目录
    } catch (\Exception $e) {
        echo $e->getCode();
        echo $e->getMessage();
    }
    fclose($fh);
    unlink($dir);

    return $img_url = UPYUN_DOMAIN . '/twoCode/' . $img;
}

/**
 * 图片上传
 * @param array $files  通常是 $_FILES数组
 * @param array $config 上传配制
 * @param array $driver 上传驱动
 * @param array $driverConfig 驱动配制
 * @return array
 */
function upload_img($files = [], $config = [], $driver = '', $driverConfig = null) {
    Config::load(CONF_PATH . 'aliyun' . CONF_EXT);
    $upload_img = Config::get('upload_img');
    if (empty($files)) {
        return data_error('没有要上传的图片');
    }
    if (!empty($config)) {
        $config = array_merge($upload_img, $config);
    } else {
        $config = $upload_img;
    }
    //删除空文件信息
    foreach ($files as $k => $v) {
        if (empty($v['name'])) {
            unset($files[$k]);
        }
    }
    $upload = new \org\Upload($config, $driver, $driverConfig);
    $res = $upload->upload($files);
    if ($res) {
        return data_success($res);
    } else {
        return data_error($upload->getError());
    }
}

/**
 * 数据返回 错误
 * @param $msg 消息
 * @param $data 数据
 * @param $code 状态码
 * @return array
 */
function data_error($msg = '', $data = [], $code = false) {
    return data_success($msg, $data, $code);
}

/**
 * 数据返回 正确
 * @param $msg 消息
 * @param $data 数据
 * @param $code 状态码
 * @return array
 */
function data_success($msg = '', $data = [], $code = true) {
    return ['code' => $code, 'msg' => $msg, 'data' => $data];
}

function gmt_iso8601($time) {
    $dtStr = date("c", $time);
    $mydatetime = new DateTime($dtStr);
    $expiration = $mydatetime->format(DateTime::ISO8601);
    $pos = strpos($expiration, '+');
    $expiration = substr($expiration, 0, $pos);
    return $expiration . "Z";
}

/**

 *  　判断是否合法车牌号
 * 　　@name isCarLicense
 * 　　@param $license
 * 　　@return bool
 */
function isCarLicense($license) {
    if (empty($license)) {
        return false;
    }
    /* 匹配民用车牌和使馆车牌
      # 判断标准
      # 1，第一位为汉字省份缩写
      # 2，第二位为大写字母城市编码
      # 3，后面是5位仅含字母和数字的组合
     * 
     */

    $regular = "/[京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼川贵云渝藏陕甘青宁新使]{1}[A-Z]{1}[0-9a-zA-Z]{5}$/u";
    preg_match($regular, $license, $match);
    if (isset($match[0])) {
        return true;
    }
    //匹配特种车牌(挂,警,学,领,港,澳)
    //参考 https://wenku.baidu.com/view/4573909a964bcf84b9d57bc5.html

    $regular = '/[京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼川贵云渝藏陕甘青宁新]{1}[A-Z]{1}[0-9a-zA-Z]{4}[挂警学领港澳]{1}$/u';
    preg_match($regular, $license, $match);
    if (isset($match[0])) {
        return true;
    }
    /*
      #匹配新能源车辆6位车牌
      #参考 https://baike.baidu.com/item/%E6%96%B0%E8%83%BD%E6%BA%90%E6%B1%BD%E8%BD%A6%E4%B8%93%E7%94%A8%E5%8F%B7%E7%89%8C
     */
    #小型新能源车
    $regular = "/[京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼川贵云渝藏陕甘青宁新]{1}[A-Z]{1}[DF]{1}[0-9a-zA-Z]{5}$/u";
    preg_match($regular, $license, $match);
    if (isset($match[0])) {
        return true;
    }
    #大型新能源车
    $regular = "/[京津冀晋蒙辽吉黑沪苏浙皖闽赣鲁豫鄂湘粤桂琼川贵云渝藏陕甘青宁新]{1}[A-Z]{1}[0-9a-zA-Z]{5}[DF]{1}$/u";
    preg_match($regular, $license, $match);
    if (isset($match[0])) {
        return true;
    }

    return false;
}

/**
 * POST 模拟提交
 * @param string $url
 * @param array $postFields
 * @param array $setHeader
 * @return mixed
 */
function curlPost($url, $postFields = null, $setHeader = null) {
    if (!function_exists('curl_init')) {
        exit('php.ini php_curl must is Allow! ');
    }
    $url_ary = parse_url($url);
    $ch = curl_init();
    if ('https' == $url_ary['scheme']) {
        curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    }
    if ($setHeader) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $setHeader);
    }

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FAILONERROR, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if (is_array($postFields) && 0 < count($postFields)) {
        $postBodyString = "";
        foreach ($postFields as $k => $v) {
            $postBodyString .= "$k=" . urlencode($v) . "&";
        }
        unset($k, $v);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, substr($postBodyString, 0, -1));
    } elseif ($postFields) {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    }
    $reponse = curl_exec($ch);
    if ($reponse === false) {
        exit(curl_error($ch));
    } else {
        $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        //print_r($httpStatusCode);
        if (200 !== $httpStatusCode) {
            if ($setHeader) {
                return $reponse;
            } else {
                exit($reponse . '&nbsp;code:' . $httpStatusCode);
            }
        }
    }
    curl_close($ch);
    return $reponse;
}

/**
 * 将非UTF-8字符集的编码转为UTF-8
 *
 * @param mixed $mixed 源数据
 *
 * @return mixed utf-8格式数据
 */
function charsetToUTF8($mixed) {
    if (is_array($mixed)) {
        foreach ($mixed as $k => $v) {
            if (is_array($v)) {
                $mixed[$k] = charsetToUTF8($v);
            } else {
                $encode = mb_detect_encoding($v, array('ASCII', 'UTF-8', 'GB2312', 'GBK', 'BIG5'));
                if ($encode == 'EUC-CN') {
                    $mixed[$k] = iconv('GBK', 'UTF-8', $v);
                }
            }
        }
    } else {
        $encode = mb_detect_encoding($mixed, array('ASCII', 'UTF-8', 'GB2312', 'GBK', 'BIG5'));
        if ($encode == 'EUC-CN') {
            $mixed = iconv('GBK', 'UTF-8', $mixed);
        }
    }
    return $mixed;
}

//验证身份证
function is_idcard($id) {
    $id = strtoupper($id);
    $regx = "/(^\d{15}$)|(^\d{17}([0-9]|X)$)/";
    $arr_split = array();
    if (!preg_match($regx, $id)) {
        return FALSE;
    }
    if (15 == strlen($id)) { //检查15位
        $regx = "/^(\d{6})+(\d{2})+(\d{2})+(\d{2})+(\d{3})$/";

        @preg_match($regx, $id, $arr_split);
        //检查生日日期是否正确
        $dtm_birth = "19" . $arr_split[2] . '/' . $arr_split[3] . '/' . $arr_split[4];
        if (!strtotime($dtm_birth)) {
            return FALSE;
        } else {
            return TRUE;
        }
    } else {      //检查18位
        $regx = "/^(\d{6})+(\d{4})+(\d{2})+(\d{2})+(\d{3})([0-9]|X)$/";
        @preg_match($regx, $id, $arr_split);
        $dtm_birth = $arr_split[2] . '/' . $arr_split[3] . '/' . $arr_split[4];
        if (!strtotime($dtm_birth)) { //检查生日日期是否正确
            return FALSE;
        } else {
            //检验18位身份证的校验码是否正确。
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
            $arr_int = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
            $arr_ch = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
            $sign = 0;
            for ($i = 0; $i < 17; $i++) {
                $b = (int) $id{$i};
                $w = $arr_int[$i];
                $sign += $b * $w;
            }
            $n = $sign % 11;
            $val_num = $arr_ch[$n];
            if ($val_num != substr($id, 17, 1)) {
                return FALSE;
            } //phpfensi.com
            else {
                return TRUE;
            }
        }
    }
}
