<?php
/*
 * author wuningwen
 * 2019-1-18
 * Pioneering works 
 */
namespace app\index\controller;

use app\common\controller\HomeBase;
use think\Db;

class Login extends HomeBase {

    public function index() {
        dump($this->h_uid);
        
//        return $this->fetch();
    }
    /* 
     * 登陆请求接口
     * post
     * tel-手机号，code--验证码
     */
    public function dologin(){
         if ($this->request->isPost()) {
            $tel = input('post.tel');
            $code = input('post.code');
            if (empty($tel)) {
                return $this->apiError('请输入正确的手机号');
            }
            if (empty($code)) {
                return $this->apiError('请填写正确的验证码');
            }
            $user_ser = new \app\common\server\user\UserServer();
            $result = $user_ser->loginIn(['tel' => $tel, 'code' => $code, 'version' => $version]);
            if ($result['code'] == 1000) {
                return $this->apiSuccess([], '登录成功');
            } else {
                return $this->apiError($result['msg']);
            }
        } else {
            return view('/404');
        }
    }

}
