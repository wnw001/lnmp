<?php

namespace app\index\controller;

use app\common\controller\HomeBase;
use app\common\model\Article as ArticleModel;
use app\common\model\Category as CategoryModel;
use think\Db;
class Index extends HomeBase {

    protected function _initialize() {
        parent::_initialize();
        $this->article_model = new ArticleModel();
        $this->category = new CategoryModel();
        $res_image_url = Db::name('config')->where('id=6')->find();
        $this->res_image_url = $res_image_url['value'];
        $this->assign('res_image_url',$res_image_url);
    }

    public function index() {
       $res_banner = Db::name('article')->where('cid=3')->field('id,title,image_url')->select();
       $res_product = Db::name('article')->where('cid=4')->field('id,title,image_url')->select();
       $res_index_product = Db::name('article')->where('cid=6 or cid=7 or cid=8')->field('id,title,image_url,introduction')->order('cid asc')->select();
       foreach ($res_index_product as $key => $value) {
           $res_index_product[$key]['image_arr'] = explode(',', $value['image_url']);
       }
       $res_houban = Db::name('article')->where('cid=9')->field('id,title,image_url')->select();
        return $this->fetch('index/index',['res_banner'=>$res_banner,'res_product'=>$res_product,'res_index_product'=>$res_index_product,'res_houban'=>$res_houban]);
    }
    public function pcase() {
       $list = Db::name('article')->where('cid=14')->find();
       $list['image_arr'] = explode(',', $list['image_url']);
       $list_list = Db::name('article')->where('cid=15')->field('title,image_url')->select();
       foreach ($list_list as $key => $value) {
           $list_list[$key]['image_url'] = $this->res_image_url.$value['image_url'];
       }
       $list_list = json_encode($list_list);
        return $this->fetch('index/case',['list'=>$list,'list_list'=>$list_list]);
    }
    public function service() {
       $list = Db::name('article')->where('cid=17')->find();
       $list_ser = Db::name('article')->where('cid=18')->select();
       $list_addr = Db::name('article')->where('cid=19')->find();
        return $this->fetch('index/service',['list'=>$list,'list_ser'=>$list_ser,'list_addr'=>$list_addr]);
    }
    public function details($idd) {
       $list = Db::name('article')->where('cid='.$idd)->find();
       $list['image_arr'] = explode(',', $list['image_url']);
        return $this->fetch('index/details',['list'=>$list]);
    }
    public function about() {
       $list = Db::name('article')->where('cid=21')->field('id,title,image_url,introduction')->find();
       $list_two = Db::name('article')->where('cid=22')->field('id,title,image_url,introduction')->find();
       $list_three = Db::name('article')->where('cid=23')->field('id,title,image_url,introduction')->find();
       $list_three['image_arr'] = explode(',', $list_three['image_url']);
       $list_three['in_arr'] = explode('---', $list_three['introduction']);
        return $this->fetch('index/about',['list'=>$list,'list_two'=>$list_two,'list_three'=>$list_three]);
    }
}
