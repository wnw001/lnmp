<?php
return [
    // 阿里云短信配置
    'signName'            => '助宝',
    'TemplateCode_one'        => 'SMS_178771025',//手机号验证
    'TemplateCode_two'        => 'SMS_174485507',//短信登陆
    'accessKeyId'        => 'aliyun_accessKeyId',
    'accessKeySecret'        => 'aliyun_accessKeySecret',
    'endpoint'=> 'aliyun_endpoint',
    'bucket' => 'aliyun_bucket',
    'domain'        => '',
    'site_img_url' => 'aliyun_site_img_url',//图片域名
    'website_url' => 'web_url',//网站域名
    //图片上传
    'upload_img'               => [
        //默认路径
        'savePath' => 'default',
        //上传类型
        'FilExt' => 'jpg,jpeg,png,gif,bmp',
        //上传大小，KB
        'MaxSize' => 2048,
        'imgSize' => 5120,
        //是否生成缩略图
        'isThumb' => 0,
        //缩略图宽度
        'thumbWidth' => 150,
        //缩略图高度
        'thumbHeight' => 150,
    ],
    'payAppId' => '',//支付appid
    'rsaPrivateKey' => 'HpeVA=',//应用私钥
    'alipayrsaPublicKey' => '//++/3cY0l22ADcNKGtK2HVWG7d5qdDkZFQfCZJICcDjJ5WGFu9n3jVv0zUbxZ3n0YythUBqMxI4EKpS+PY+IiTfT6mYyNXj6muoaDCnaZgLUrXOFD/tNiaJgU3+Bt2yeUNMKrovWtzUloWJZi9ZhA79+xGchI8d56If3fBNvlSlFgiGBRVlOanqs4MhHvGjr/Hrxu5Syc8RW0k00cuEOWIwIDAQAB',//支付宝公钥
];
    
