<?php
/**
 * 第三方key
 */

return [
    
    //极光测试key
    'jpush_test' =>[
        'key' => '',
        'secret' => ''
    ],
    
    //极光正式key
    'jpush' =>[
        'key' => '',
        'secret' => ''
    ],

    //信鸽测试key
    'XGPush_test' =>[
        'android_access_id' => '',
        'android_access_key' => '',
        'android_secret_key' => '',
        'ios_access_id' => '',
        'ios_access_key' => '',
        'ios_secret_key' => ''
    ],
    
    //信鸽正式key
    'XGPush' =>[
        'android_access_id' => '',
        'android_access_key' => '',
        'android_secret_key' => '',
        'ios_access_id' => '',
        'ios_access_key' => '',
        'ios_secret_key' => ''
    ],
    //七牛测试key
    'qiniu_test' =>[
        'accessKey' => "",
        'secretKey' => "",
        'bucket' => "",
    ],
    
    //七牛正式key
    'qiniu' =>[
        'accessKey' => "",
        'secretKey' => "",
        'bucket' => "",
    ],

   //极验证
    'geetest' => [
        'captcha_id' =>'',
        'private_key' => ''
    ],

    //股票
    'api51' =>[
        'api_url' => '',
        'token'=>'',
    ],
    //聚合
    'juhe' =>[
        'juht_api_url' => '',
        'juhe_appKey' => ''
    ],
    //深圳选股股票接口
    'szxg' => [ 
        'api_url' => '',
        'aes_key' => ''
    ],

];