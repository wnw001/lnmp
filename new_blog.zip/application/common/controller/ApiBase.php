<?php

namespace app\common\controller;

use think\Config;
use think\Session;
use think\Controller;
use app\common\common\Aes;
use app\common\server\WxAuthorizeServer;

class ApiBase extends Controller {

    var $platform; //平台标识
    var $version; //内部版本号      
    var $imei; //设备唯一码
    var $umeng_device; //友盟设备码
    var $opact; //接口地址  Article/problen
    var $signkey; //验签值
    var $versions;  //版本信息
    var $versionIndex;
    var $des_data; 
    var $debug; //debug==1113线上建议要去掉，不要留后门
    var $session;
    //登录用户基础数据
    protected $loginUser = array();

    protected function _initialize() {
        header('Content-Type:application/json;charset=utf-8');
        header("Access-Control-Allow-Origin:*");
        parent::_initialize();    
        $action = input('post.opact');
        $uncheck = array('test/index','article/problem','login/login','sms/aliyun');
//        if (!in_array($action, $uncheck)) {
//            if(empty(Session::get('user_array'))){
//                $this->apiError('请先登陆');
//            }
//        }
        self::getVersionIndex();//参数验证--数据加解密    
        $this->des_data['user_array'] = Session::get('user_array'); //用户信息数组
        $this->des_data['wx_openid'] = Session::get('wx_openid'); //微信openid
        $this->des_data['user_wx_info_id'] = Session::get('user_wx_info_id'); //授权数据表id
    }

    /**
     * 根据请求的版本号信息【$this->version】搜索对应的版本配置信息
     * @author wuningwen
     * 该接口两种请求模式：1：测试环境使用debug=1113则请求数据不用加密，2：线上模式 debug将关闭，请求数据得使用AES加密
     */
    public function getVersionIndex() {
        $this->versions = Config::get('versions');
        $versionsKey = array_keys($this->versions); //将配置里的key变成数组的值
        $this->version = $this->version ? $this->version : input('post.version');       
        $enSign = input('post.'); //加密后的字符串    
        $enSign = $enSign['enData'];
        if (empty($this->version)) {
            $this->apiError('接口版本号不能为空');
        }
        $versionIndex = array_search($this->version, $versionsKey); //匹配$this->version的值是否在$versionsKey里任一个值与之相同，有则返回key值
        if ($versionIndex === FALSE) {
            $tmpVersionarr = explode('_', $this->version);
            $IS_TRUE = TRUE;
            $i = 0;
            while ($IS_TRUE) {
                $version_num = count($tmpVersionarr) - $i;
                $tmpVersion = $tmpVersionarr[0] . '_' . $tmpVersionarr[1] . '_' . $tmpVersionarr[2];
                $versionIndex = array_search($tmpVersion, $versionsKey);
                if ($versionIndex === FALSE) {
                    $tmpVersionarr[$version_num] = '*';
                    $i++;
                } else {
                    $IS_TRUE = false;
                }
                if ($i > 10) {
                    $versionIndex = $IS_TRUE = false;
                }
            }
        }
        //异常处理
        if ($versionIndex === FALSE) {
            $this->apiError('错误的参数请求.');
        }
        $this->versionIndex = $versionIndex;
        $this->debug = input('post.debug');
        if ($this->debug == 1113) {  
            $check_res = $enSign;
        } else {           
            $check_res = $this->checkSign($enSign);
        }
        if ($check_res == FALSE) {
            $this->apiError('参数签名错误');
        }
        $this->des_data = $check_res;
        $this->opact = $this->des_data['opact'];
        if (!$this->des_data['opact'] || !$this->des_data['platform']) {
            $this->apiError('参数有误');
        }
    }

    /**
     * 验签检查
     */
    public function checkSign($enSign) {
        if (empty($enSign)) {
            return FALSE;
        }
        $versionSignkey = Config::get('signkey');
        $versions = array_values($this->versions);
        $version = $versions[$this->versionIndex];
        $this->signkey = isset($versionSignkey[$version]) ? $versionSignkey[$version] : '';
        //加密模式
        $des_data = $this->aesDecrypt($enSign);
        if (empty($des_data)) {
            return false;
        } else {
            return $des_data;
        }
    }

    /**
     * 接口 - 数据请求成功
     * @param array $data
     * @param string $msg
     */
    protected function apiSuccess($data = [], $msg = '成功:1000', $url_code = 0) {

        $ret['code'] = 1000;
        $ret['data'] = $data;
        $ret['msg'] = $msg;
        if (is_numeric($url_code)) {
            $ret['url_code'] = $url_code;
        } else {
            $ret['url'] = $url_code;
        }
        if ($this->debug != '1113') {
//            $en_data = $this->aesEncrypt($ret);
            $data = ['en_data' => $ret];
            echo json_encode($data);
        } else {
            echo json_encode($ret);
        }
        exit;
    }

    /**
     * 接口 - 数据请求失败
     * @param array $data
     * @param string $msg
     */
    protected function apiError($msg = '失败:1001', $code = 1001, $data = [], $url_code = 0) {
        $ret['code'] = $code;
        $ret['msg'] = $msg;
        $ret['url_code'] = $url_code;
        $ret['data'] = $data;
        if ($this->debug != '1113') {
//            $en_data = $this->aesEncrypt($ret);
            $data = ['en_data' => $ret];
            echo json_encode($data);
        } else {
            echo json_encode($ret);
        }
        exit;
    }

    /**
     * AES数据加密
     * @author 1005
     * @date 2017-7-09
     */
    public function aesEncrypt($data = []) {

        $aes = new Aes($this->signkey);
        return $aes->aesEncode(json_encode($data), $this->signkey);
    }

    /**
     * AES数据解密
     * @author 1005
     * @date 2017-7-09
     */
    public function aesDecrypt($str = '') {
        $aes = new Aes($this->signkey);
        return json_decode($aes->aesDecode($str, $this->signkey), true);
    }

    /*
     * 判断是否登录
     */

    public function checkLogin() {
        $user_session = $this->session;
        if (!$user_session) {
            $this->apiError('请先登录', 1001, '', 102);
            exit;
        }
        return $user_session;
    }

    /**
     * 字符串命名风格转换
     * type 0 将Java风格转换为C的风格 1 将C风格转换为Java的风格
     * @param string $name 字符串
     * @param integer $type 转换类型
     * @return string
     */
    public function parse_name($name, $type = 0) {
        if ($type) {
            return ucfirst(preg_replace_callback('/_([a-zA-Z])/', function($match) {
                        return strtoupper($match[1]);
                    }, $name));
        } else {
            return strtolower(trim(preg_replace("/[A-Z]/", "_\\0", $name), "_"));
        }
    }
    
    /*
     * 微信授权登陆验证
     */

    public function wxlogin() {
        if (Session::get('wx_openid')) {
            $this->apiError('不要重复授权!');
        }
        $code = input('code');        
        if ($code) { //获取openid
            $wx_server = new WxAuthorizeServer();
            $openid = $wx_server->getOpenid($code);
            if ($openid['openid']) {
                Session::set('wx_openid', $openid['openid']);
                $this->getUserOpenid($openid); //未做手机登陆前使用。如果有做手机登陆，可在注册后绑定该用户openid
            }
        } else {
            $this->apiError('请先上传code!');
        }
    }

    /*
     * 保存用户信息
     */

    public function getUserOpenid($openid) {
        $user_array = Seesion::get('user_array');
        $res = Db::name('user_wx_info')->where(['openid' => $openid['openid']])->find();
        if (empty($res)) {
            $wx_server = new WxAuthorizeServer();
            $resutl = $wx_server->getUserInfo($openid);
            if ($user_array['id']) {
                $data['u_id'] = $user_array['id'];
            }
            $data['openid'] = $openid['openid'];
            $data['nickname'] = $resutl['nickname'];
            $data['sex'] = $resutl['sex'];
            $data['province'] = $resutl['province'];
            $data['headimgurl'] = $resutl['headimgurl'];
            $data['country'] = $resutl['country'];
//            $data['unionid'] = $resutl['unionid'];
            $data['c_time'] = time();
            $res = Db::name('user_wx_info')->insertGetId($data);
            Session::set('user_wx_info_id', $res);
            $result['user_array']['user_wx_info_id'] = $res;
        } else {
            if ($res['u_id']) {
                $res_user = Db::name('user')->where('id=' . $res['u_id'])->field('id,b_id,mobile,password,province_id,is_memeber')->find();
                $res_user['headimgurl'] = $res['headimgurl'];
                $res_user['user_wx_info_id'] = $res['id'];
                Session::set('user_array', $res_user);
                $result['user_array']= $res_user;
            }
        }
        $this->apiSuccess($result);
    }
   
}
