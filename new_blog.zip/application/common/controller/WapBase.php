<?php

/*
 * 小程序用户公共基类
 */

namespace app\common\controller;

use think\Controller;
use app\common\server\WxAuthorizeServer;
use think\Db;
use think\Session;

class WapBase extends Controller {

    //登录用户基础数据
    protected $loginUser = array();

    public function _initialize() {
        parent::_initialize();
        //是否登录
        $action = strtolower(request()->controller() . '/' . request()->action());
        $uncheck = array('login/index', 'Sms/aliyun', 'RechargeOrder/notifyPay');
        if (!in_array($action, $uncheck)) {
            //登录验证
            $this->isLogin(); //小程序验证登陆
        }
    }

    /**
     * 是否登录
     */
    private function isLogin() {
        $token = input('token');
        $this->loginUser = cache('login_user_token_' . $token);
        if (!$this->loginUser) {
            $userToken = Db::name('user_token')->where(['token' => $token])->find();
            if (empty($userToken)) {
                $this->apiError('请登录');
            }
            $this->loginUser = Db::name('user_xcx_info')->where(['id' => $userToken['u_x_id']])->field('id,u_id,nickname,img_url')->find();
            if (empty($this->loginUser)) {
                $this->apiError('登录数据有误');
            }
            $this->loginUser['token'] = $token;
            cache('login_user_token_' . $token, $this->loginUser, 86400); //缓存1天
        }
    }

    /**
     * 接口 - 数据请求成功
     * @param array $data
     * @param string $msg
     */
    protected function apiSuccess($data = [], $msg = '成功:1000', $url_code = 0) {

        $ret['code'] = 1000;
        $ret['data'] = $data;
        $ret['msg'] = $msg;
        if (is_numeric($url_code)) {
            $ret['url_code'] = $url_code;
        } else {
            $ret['url'] = $url_code;
        }
        echo json_encode($ret);
        exit;
    }

    /**
     * 接口 - 数据请求失败
     * @param array $data
     * @param string $msg
     */
    protected function apiError($msg = '失败:1001', $code = 1001, $data = [], $url_code = 0) {
        $ret['code'] = $code;
        $ret['msg'] = $msg;
        $ret['url_code'] = $url_code;
        $ret['data'] = $data;
        echo json_encode($ret);
        exit;
    }

}
