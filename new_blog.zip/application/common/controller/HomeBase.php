<?php

namespace app\common\controller;

use think\Cache;
use think\Controller;
use think\Db;

class HomeBase extends Controller {

    protected function _initialize() {
        parent::_initialize();     
        $res_article_one = Db::name('article')->where('id=1')->field('id,title,introduction')->find();
        $res_article_two = Db::name('article')->where('id=2')->field('id,title,introduction')->find();
        $res_article_c = Db::name('article')->where('cid=10')->field('id,title,introduction')->find();
        $res_article_seo = Db::name('article')->where('cid=11')->field('id,title,introduction')->find();
        $res_article_code = Db::name('article')->where('cid=12')->field('id,title,image_url')->find();
        $res_article_one['result'] = explode('---', $res_article_one['introduction']);
        $res_article_two['result'] = explode('---', $res_article_two['introduction']);
        $this->assign('action',strtolower(request()->action()));
        $this->assign('res_article_one',$res_article_one);
        $this->assign('res_article_two',$res_article_two);
        $this->assign('res_article_c',$res_article_c);
        $this->assign('res_article_seo',$res_article_seo);
        $this->assign('res_article_code',$res_article_code);
    }

}
