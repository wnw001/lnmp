<?php
namespace app\common\controller;

use org\BusinessAuth;
use think\Loader;
use think\Cache;
use think\Controller;
use think\Db;
use think\Session;
use think\Request;

/**
 * 商户后台公用基础控制器
 * Class HomenewBase
 * @package app\common\controller
 */
class HomenewBase extends Controller
{
    protected function _initialize()
    {
        parent::_initialize();
        $this->checkAuth();
        $this->getMenu();
        $this->actionLog();
        // 输出当前请求控制器（配合后台侧边菜单选中状态）
        $this->assign('controller', Loader::parseName($this->request->controller()));
    }

    /**
     * 权限检查
     * @return bool
     */
    protected function checkAuth()
    {

        if (!Session::has('business_admin_id')) {
            $this->redirect('home/login/index');
        }

        $module     = $this->request->module();
        $controller = $this->request->controller();
        $action     = $this->request->action();

        // 排除权限
        $not_check = ['home/Index/index', 'home/AuthGroup/getjson', 'home/System/clear'];

        if (!in_array($module . '/' . $controller . '/' . $action, $not_check)) {
            $auth     = new BusinessAuth();
            $admin_id = Session::get('business_admin_id');
            if (!$auth->check($module . '/' . $controller . '/' . $action, $admin_id) && $admin_id != 1) {
                $this->error('没有权限');
            }
        }
    }

    /**
     * 获取侧边栏菜单
     */
    protected function getMenu()
    {
        $menu     = [];
        $admin_id = Session::get('business_admin_id');
        $auth     = new BusinessAuth();

        $auth_rule_list = Db::name('business_auth_rule')->where('status', 1)->order(['sort' => 'DESC', 'id' => 'ASC'])->select();

        foreach ($auth_rule_list as $value) {
            if ($auth->check($value['name'], $admin_id) || $admin_id == 1) {
                $menu[] = $value;
            }
        }
        $menu = !empty($menu) ? array2tree($menu) : [];
        $this->assign('menu', $menu);
    }
    /*
     * 记录日志--有增删改的日志
     */

    public function actionLog() {

        $action = strtolower(request()->controller() . '/' . request()->action());
        if (in_array('home/' . $action, $this->setAction())) {
            $where['name'] = 'home/' .$action;
            $res = Db::name('business_auth_rule')->where($where)->find();
            $data['data'] = serialize($this->request->param());
            $request = Request::instance();
            $data['uid'] = Session::get('business_admin_id');
            $data['create_time'] = time();
            $data['action'] = $request->url();
            $data['b_id'] = Session::get('business_admin_b_id');
            $data['action_name'] = $res['title'];
            Db::name('business_action_log')->insert($data);
        }
    }
    /*
     * 获取需监控控制器的方法
     */

    public function setAction() {
        $action_array = array();
        $res_menu = Db::name('business_auth_rule')->where('is_record=2')->field('name')->select();
        foreach ($res_menu as $key => $value) {
            $action_array[$key] = strtolower($value['name']);
        }
        return $action_array;
    }
    
}