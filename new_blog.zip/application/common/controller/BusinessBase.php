<?php
namespace app\common\controller;

use think\Controller;
use think\Db;
use think\Session;

/**
 * 商家后台公用基础控制器
 * Class AdminBase
 * @package app\common\controller
 */
class BusinessBase extends Controller
{
    protected function _initialize()
    {
        parent::_initialize();
        $this->business_id = Session::get('business_id');
        if(empty($this->business_id)){
            $this->redirect('business/login/index');
        }
        $ac = strtolower(request()->controller() . '/' . request()->action());
        $controller = strtolower(request()->controller());
        $action = strtolower(request()->action());
        $this->assign('ac',$ac);
        $this->assign('controller',$controller);
        $this->assign('action',$action);
        
    }

    
    
}