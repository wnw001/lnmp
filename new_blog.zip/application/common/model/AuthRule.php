<?php
namespace app\common\model;

use think\Db;
use think\Model;

class AuthRule extends Model
{

}