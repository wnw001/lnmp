<?php

namespace app\common\server;


/*
 * 支付宝支付
 * auther wnw
 */

class AlipayServer {

    public function __construct() {
        
    }

    

}
