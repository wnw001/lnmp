<?php

/**
 * 公共服务模块
 * @1001 17/06/30
 */

namespace app\common\server;
require_once '/data/wwwroot/model/extend/aliyunoss/autoload.php';
use app\common\server\BaseServer;
use OSS\OssClient;
use OSS\Core\OssException;
use think\Config;
class CommonServer extends BaseServer {

    function __construct() {
        parent::__construct();
    }

    /*
     * 使用Gd库--图片中加入文字--2019-06-14
     * wuningwen
     * path 要加文字的图片地址
     * y_image_name 原来图片的名字
     * zhiti 所使用的字体路径及名称
     * n_image_name 新生成的图片名称
     * type 类别
     */

    public function imageAddWorld($path, $y_image_name, $zhiti, $n_image_name, $type) {
        ob_clean();
        $dst_path = $path . $y_image_name;
        //创建图片的实例
        $dst = imagecreatefromstring(file_get_contents($dst_path));

        //打上文字
        $font = $zhiti; //'/data/wwwroot/model/Alibaba-PuHuiTi-Medium.ttf'; //字体路径
        $black = imagecolorallocate($dst, 00, 00, 00); //字体颜色
        if ($type == 1) {
            imagefttext($dst, 10, 0, 180, 334, $black, $font, '厦门集美大学');
            imagefttext($dst, 10, 0, 420, 334, $black, $font, '吴宁文'); //第二个参数为字体大小，第三个参数为倾斜度，第四个参数为x坐标，第五个参数为y坐标
            imagefttext($dst, 10, 0, 108, 361, $black, $font, '2019');
            imagefttext($dst, 10, 0, 159, 360, $black, $font, '1');
            imagefttext($dst, 10, 0, 190, 360, $black, $font, '1');
            imagefttext($dst, 10, 0, 234, 361, $black, $font, '2019');
            imagefttext($dst, 10, 0, 284, 360, $black, $font, '9');
            imagefttext($dst, 10, 0, 314, 360, $black, $font, '1');
            imagefttext($dst, 10, 0, 170, 387, $black, $font, '201906-12');
        }

        //输出图片
        list($dst_w, $dst_h, $dst_type) = getimagesize($dst_path);
        $dir = ROOT_PATH . 'public/uploads/' . date("Ymd");
        is_dir($dir) OR mkdir($dir, 0777, true);
        switch ($dst_type) {
            case 1://GIF
                header("Content-Type: image/gif;charset=utf-8");
                imagegif($dst, $dir . '/' . $n_image_name . '.gif');
                $this->localTooss('public/uploads/' . date("Ymd").'/',$n_image_name . '.gif');
                break;
            case 2://JPG
                header("Content-Type: image/jpeg;charset=utf-8");
                imagejpeg($dst, $dir . '/' . $n_image_name . '.jpg');
                $this->localTooss('public/uploads/' . date("Ymd").'/',$n_image_name . '.jpg');
                break;
            case 3://PNG
                header("Content-Type: image/png;charset=utf-8");
                imagepng($dst, $dir . '/' . $n_image_name . '.png');
                $this->localTooss('public/uploads/' . date("Ymd").'/',$n_image_name . '.png');
                break;
            default:
                break;
        }
        

        imagedestroy($dst);
        exit;
    }
    
    /*
     * 移动本地图片到oss
     */
    public function localTooss($path,$image_name){
        Config::load(CONF_PATH . 'aliyun' . CONF_EXT);
        $accessKeyId = Config::get('accessKeyId');
        $accessKeySecret = Config::get('accessKeySecret');
        $endpoint = Config::get('endpoint');
        $bucket = Config::get('bucket');
        // 文件名称 
        $object = $path.$image_name; // <yourLocalFile>由本地文件路径加文件名包括后缀组成，例如/users/local/myfile.txt 
        $filePath = ROOT_PATH.$path.$image_name;
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, false);
            $result = $ossClient->uploadFile($bucket, $object, $filePath);
        } catch (OssException $e) {
            return $e->getMessage();
        }
    }

}
