<?php

/**
 * 用户模块
 * @1001 17/06/30
 */

namespace app\common\server\user;

use app\common\server\BaseServer;
use think\cache\driver\Redis;
use think\Db;

class UserServer extends BaseServer {

    private $cache;

    function __construct() {
        parent::__construct();
        $this->cache = new Redis();
    }

    /*
     * 小程序授权--更新或添加小程序用户信息数据
     * $data 小程序数据
     */

    public function xcxUserUpdate($data) {
        $where['openid'] = $data['openId'];       
        $user_xcx_info = Db::name('user_xcx_info')->where($where)->find();
        $user_array['token'] = md5($data['openId'] . $data['session_key']);
        if (empty($user_xcx_info)) {
            $d['openid'] = $data['openId'];
            $d['nickname'] = $data['nickName'];
            $d['gender'] = $data['gender'];
            $d['language'] = $data['language'];
            $d['city'] = $data['city'];
            $d['province'] = $data['province'];
            $d['img_url'] = $data['avatarUrl'];
            $d['unionid'] = isset($data['unionId'])?$data['unionId'] : '';
            $d['c_time'] = $data['watermark']['timestamp'];
            $result = Db::name('user_xcx_info')->insertGetId($d);
            $d_token['token'] = $user_array['token'];
            $d_token['login_time'] = time();
            $d_token['openid'] = $d['openid'];
            $d_token['u_x_id'] = $result;
            $result_token = Db::name('user_token')->insertGetId($d_token);

            $user_array['u_id'] = $user_xcx_info['u_id'] ? $user_xcx_info['u_id'] : 0;
            $user_array['id'] = $result;
            $user_array['nickname'] = $data['nickName'];
            $user_array['img_url'] = $data['avatarUrl'];
            cache('login_user_token_' . $user_array['token'], $user_array, 86400); //缓存1天        
        } else {
            $where_token['u_x_id'] = $user_xcx_info['id'];
            $where_token['token'] = $user_array['token'];
            $result_token = Db::name('user_token')->where($where_token)->field('id,u_x_id')->find();  
            if (empty($result_token)) {
                $user_array['u_id'] = $user_xcx_info['u_id'] ? $user_xcx_info['u_id'] : 0;
                $user_array['id'] = $user_xcx_info['id'];
                $user_array['token'] = $user_array['token'];
                $user_array['nickname'] = $user_xcx_info['nickname'];
                $user_array['img_url'] = $user_xcx_info['img_url'];
                $data_token['token'] = $user_array['token'];
                $data_token['u_time'] = time();
                $res = Db::name('user_token')->where('u_x_id='.$user_xcx_info['id'])->update($data_token);
                cache('login_user_token_' . $user_array['token'], $user_array, 86400); //缓存1天 
            }
        }
        return $user_array['token'];
    }
    /*
     * 用户提交车资料验证
     */
    public function userDataAdd($data){
        if (!is_mobilephone($data['mobile']) || strlen($data['mobile']) != 11) {
            return ['code' => 1001, 'msg' => '请填写正确的手机号码'];
        }
        if (strlen($data['sms_code']) != 4 || !is_numeric($data['sms_code'])) {
            return ['code' => 1001, 'msg' => '请填写正确的验证码'];
        }    
        if (is_idcard($data['id_card'])==FALSE) {
            return ['code' => 1001, 'msg' => '身证格式不正确'];
        }    
    }

}
