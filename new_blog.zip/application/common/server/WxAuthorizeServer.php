<?php

namespace app\common\server;

use think\Config;

/**
 * 微信授权登陆
 * 1：获取code
 * 2:通过code获取access_token,openid
 * 3:通过access_token,openid获取用户信息
 */
class WxAuthorizeServer {

    protected $appid;
    protected $appsecret;

    public function __construct($type = '') {
        Config::load(CONF_PATH . 'weixin' . CONF_EXT);
        $this->appid = Config::get('appId');
        $this->appsecret = Config::get('appSecret');
        $this->redirect_uri = Config::get('redirect_uri');
    }

    /**
     * 获取微信openid
     * @param $code 微信授权获取的code
     * @return array  {access_token,expires_in,refresh_token,openid,scope}
     */
    public function getOpenid($code) {
        $url = "https://api.weixin.qq.com/sns/oauth2/access_token?" .
                "appid={$this->appid}" .
                "&secret={$this->appsecret}" .
                "&code={$code}&grant_type=authorization_code";
        $cu = curl_init();
        curl_setopt($cu, CURLOPT_URL, $url);
        curl_setopt($cu, CURLOPT_RETURNTRANSFER, 1);
        $ret = curl_exec($cu);
        curl_close($cu);
        return json_decode($ret, TRUE);
    }

    /*
     * 跳转网页授权
     * 需注意问题
     * scope作用域问题：作用域为snsapi_userinfo则可让用点击授权获取用户信息，如果为snsapi_base则不用点击授权直接获取openid及access_token
     * snsapi_base只能获取access_token和openID，流程走完即终止   snsapi_userinfo可以获取更详细的用户资料，比如头像、昵称、性别等
     */

    public function getCode() {       
        $state = md5(time());
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        if (strpos($user_agent, 'MicroMessenger') != false || strpos($user_agent, 'Windows Phone') != false) {
            $url = "https://open.weixin.qq.com/connect/oauth2/authorize?" .
                    "appid=" . $this->appid .
                    "&redirect_uri=" . urlencode($this->redirect_uri) .
                    "&response_type=code" .
                    "&scope=snsapi_userinfo&state=".$state."#wechat_redirect";
            header("Location:$url");
            exit;
        }
    }
    /*
     * 获取用户信息
     */
    public function getUserInfo($data){
        $info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token='.$data['access_token'].'&openid='.$data['openid'];
        $info_arr = json_decode($this->https_request($info_url),true);
        return $info_arr;
    }
    /**
     * https请求
     * @param  $url  请求网址
     */
    public function https_request($url , $data = null)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}