<?php

/**
 * 微信小程序登录类
 */

namespace app\common\server;
use think\Config;
class WxxcxLoginServer {

    private $xcxConfig;
    private $code;
    private $sessionKey;
    private $encryptedData;
    private $iv;
    private $openid;

    public function __construct($data) {
        //请求参数
        $this->code = $data['code'];
        $this->encryptedData = $data['encryptedData'];
        $this->iv = $data['iv'];
        if (empty($this->code) || empty($this->iv)) {
            throw new WxLoginException('CODE有误');
        }
        //登录配制
        $this->xcxConfig = Config::load(CONF_PATH . 'weixin' . CONF_EXT);
//        dump($this->xcxConfig);
    }

    private function setSessionKey() {
        $token_url = 'https://api.weixin.qq.com/sns/jscode2session?appid=' .
                $this->xcxConfig['appid'] . '&secret=' .
                $this->xcxConfig['appsecret'] . '&js_code=' .
                $this->code . '&grant_type=authorization_code';
        $response = $this->get_url_contents($token_url);
        $params = json_decode($response, true);
        if (isset($params['openid'])) {
            $this->sessionKey = $params['session_key'];
            $this->openid = $params['openid'];
            $result['session_key'] = $this->sessionKey;
            return $result;
        } else {
            return data_error($params['errmsg']);
        }
    }

    /**
     * 检验数据的真实性，并且获取解密后的明文.
     * @param $encryptedData string 加密的用户数据
     * @param $iv string 与用户数据一同返回的初始向量
     * @param $data string 解密后的原文
     *
     * @return int 成功0，失败返回对应的错误码
     */
    public function decryptData($encryptedData, $iv) {
        $res = $this->setSessionKey();
        if (strlen($this->sessionKey) != 24) {
            data_error('-41001');
        }
        $aesKey = base64_decode($this->sessionKey);
        if (strlen($iv) != 24) {
            return data_error('-41002');
        }
        $aesIV = base64_decode($iv);

        $aesCipher = base64_decode($encryptedData);

        $result = openssl_decrypt($aesCipher, "AES-128-CBC", $aesKey, 1, $aesIV);
        $dataObj = json_decode($result);
        if ($dataObj == NULL) {
            return data_error('-41003');
        }
        if ($dataObj->watermark->appid != $this->xcxConfig['appid']) {
            return data_error('-41003');
        }
        $dataObj->session_key = $res['session_key'];
        return $dataObj;
    }

    public function getXcxUserInfo() {
        $result = $this->decryptData($this->encryptedData, $this->iv);
        $result = $this->object_array($result);
        if ($result['session_key']) {
            return $result;
        }
    }

    public function get_user_info($data) {
        $get_user_info = "https://api.weixin.qq.com/sns/userinfo?"
                . "access_token=" . $data['access_token']
                //. "&oauth_consumer_key=" . $_SESSION["appid"]
                . "&openid=" . $data['openid']
                . '&lang=zh_CN';

        $info = $this->get_url_contents($get_user_info);
        $arr = json_decode($info, true);
        $arr = $this->getGBK($arr, CHARSET);

        return $arr;
    }
    
    public function object_array($array) {  
    if(is_object($array)) {  
        $array = (array)$array;  
     } if(is_array($array)) {  
         foreach($array as $key=>$value) {  
             $array[$key] = $this->object_array($value);  
             }  
     }  
     return $array;  
}
    function get_url_contents($url) {
        if (ini_get("allow_url_fopen") == "1")
            return file_get_contents($url);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_URL, $url);
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }

    /**
     * 得到数组变量的GBK编码
     *
     * @param array $key 数组
     * @param string $charset 编码
     * @return array 数组类型的返回结果
     */
    function getGBK($key, $charset) {
        /**
         * 转码
         */
        if (strtoupper($charset) == 'GBK' && !empty($key)) {
            if (is_array($key)) {
                $result = var_export($key, true); //变为字符串
                $result = iconv('UTF-8', 'GBK', $result);
                eval("\$result = $result;"); //转换回数组
            } else {
                $result = iconv('UTF-8', 'GBK', $key);
            }
        } else {
            $result = $key;
        }
        return $result;
    }

}

/**
 * 微信支付API异常类
 * @author ssp
 */
class WxLoginException extends \Exception {

    public function errorMessage() {
        return $this->getMessage();
    }

}
