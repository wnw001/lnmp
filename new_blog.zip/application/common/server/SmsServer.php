<?php

namespace app\common\server;

use aliyunsms\SignatureHelper;

/*
 * 统一短信发送server
 * 旨在整合全网所有sms_sdk接口
 * 提供控制层直接调用
 * auther wnw
 */

class SmsServer {

    public function __construct() {
        
    }

    public function aliyunSmsSend($PhoneNumbers, $SignName, $TemplateCode, $sms_code, $accessKeyId, $accessKeySecret) {
        header("Content-Type: text/plain; charset=utf-8"); // 输出为utf-8的文本格式
        $params = array();
        $security = false;
        $accessKeyId = $accessKeyId;
        $accessKeySecret = $accessKeySecret;
        $params["PhoneNumbers"] = $PhoneNumbers;
        $params["SignName"] = $SignName;
        $params["TemplateCode"] = $TemplateCode;
        // fixme 可选: 设置模板参数, 假如模板中存在变量需要替换则为必填项
        $params['TemplateParam'] = Array(
            "code" => $sms_code
        );
        // *** 需用户填写部分结束, 以下代码若无必要无需更改 ***
        if (!empty($params["TemplateParam"]) && is_array($params["TemplateParam"])) {
            $params["TemplateParam"] = json_encode($params["TemplateParam"], JSON_UNESCAPED_UNICODE);
        }
        try {
            // 初始化SignatureHelper实例用于设置参数，签名以及发送请求
            $helper = new SignatureHelper();
            // 此处可能会抛出异常，注意catch
            $content = $helper->request(
                    $accessKeyId, $accessKeySecret, "dysmsapi.aliyuncs.com", array_merge($params, array(
                "RegionId" => "cn-hangzhou",
                "Action" => "SendSms",
                "Version" => "2017-05-25",
                    )), $security
            );
        } catch (Exception $e) {
            echo $e->getMessage();
        }
        return object_to_array($content);
    }

}
