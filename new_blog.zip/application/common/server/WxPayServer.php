<?php
namespace app\common\server;

use app\common\server\BaseServer;
use think\Config;
/**
 * 微信支付
 * @author: wuningwen
 * @since: 2019-03-23
 */
class WxPayServer extends BaseServer{
    protected $merchant_id;
    protected $merchant_key;
    protected $appid;
   
    public function __construct(){
        Config::load(CONF_PATH . 'weixin' . CONF_EXT);
        $this->merchant_id = Config::get('partnerId');
        $this->merchant_key = Config::get('apiKey');
        $this->appid = Config::get('appId');
        $this->notify_url = Config::get('notify_url');
    }
    
    /**
     * H5 支付相关参数生成
     * @param $prepay_id 统一下单接口返回的prepay_id
     * @return array  getBrandWCPayRequest
     */
    public function getJsapiParam($prepay_id){
        $nonce_str = md5(uniqid());
        $sign_data = array(
            'appId'            => $this->wechat_config['APPID'],
            'timeStamp'        => time(),
            'nonceStr'         => $nonce_str,
            'package'          => 'prepay_id='.$prepay_id,
            'signType'         => 'MD5',
        );
        $sign = $this->setWxSign($sign_data);
        $sign_data['paySign'] = $sign;
        ksort($sign_data);
        return $sign_data;
    }
         

   

    /**
     * 生成微信支付签名
     * @param $sign_data 签名数据
     * @return string
     */
    public function setWxSign($sign_data) {
        if (isset($sign_data['sign'])) unset($sign_data['sign']);
        ksort($sign_data);
        $sign_str = urldecode(http_build_query($sign_data));
        return strtoupper(md5($sign_str.'&key='.$this->merchant_key));   
    }

    /**
     * 获取微信预支单
     * @param $out_trade_no 存票订单号
     * @param $total_fee 金额
     * @return int
     */
    public function createPrepay(){
        //充值金额限制两位小数
        $data = input('post.');
//        if(round($data['money'],2) < $data['money']){
//            $data['money'] = ((round($data['money'],2) * 100) + 1) / 100;
//        } else {
//            $data['money'] = round($data['money'],2);
//        }
        //微信接口参数
        $spbill_create_ip = get_client_ip();
        $nonce_str = uniqid();
        $pay_time_limit = 1800;
        $time_start = date('YmdHis',time());//交易开始时间
        $time_expire = date('YmdHis',time() + $pay_time_limit);//交易结束时间
        //开启开飞机0.01
        $total_fee = 0.01;
        $sign_data = array(
            'appid'             => $this->appid,
            'mch_id'            => $this->merchant_id,
            'nonce_str'         => $nonce_str,
            'spbill_create_ip'  => get_client_ip(),
            'body'              => '青云学派测试',
            'out_trade_no'      => build_order_no(),
            'total_fee'         => $total_fee, //微信已分为单位
            'spbill_create_ip'  => $spbill_create_ip,
            'notify_url'        => $this->notify_url,
            'fee_type'          => 'CNY',
            'time_start'        => $time_start,
            'time_expire'       => $time_expire,
            //'detail'            => '订单的detail',
        );
       
        $sign = $this->setWxSign($sign_data);
        $sign_data['sign'] = $sign;
        ksort($sign_data);
        //请求日志       
        $xml = array_to_xml($sign_data);
        dump($xml);exit;
        $post_url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
        $response_xml = $this->https_get($post_url,$xml);
        $response_arr = $this->setXmlArray($response_xml);
        if ($response_arr['return_code'] == 'SUCCESS' && $response_arr['return_msg'] == 'OK') {
            if ($data['trade_type'] && $data['trade_type'] === 'NATIVE') {
                return CpSuccess($response_arr['code_url']);    //返回扫码支付的二维码地址
            }
            return CpSuccess($response_arr['prepay_id']);
        } else {
            return CpError(CP_ERROR, $response_arr['return_msg']);
        }
    }
    /*
     * 微信退款测试
     * @param $data
     * */
    public function wx_drawback($data){
        //开启开飞机0.01
        if(PAY_DEBUG && in_array($_SERVER['HTTP_HOST'],$this->debug_host)){
            $total_fee = 1;
        } else {
            $total_fee = $data['money'] * 100;
        }
        $nonce_str = uniqid();
        $sign_data = array(
            'appid'             => $this->wechat_config['APPID'],
            'mch_id'            => $this->wechat_config['MCH_ID'],
            'nonce_str'         => $nonce_str,
            'transaction_id'    => $data['pay_sn'],
            'out_refund_no'      => $data['pay_sn'],
            'total_fee'         => $total_fee, //微信已分为单位
            'refund_fee'        =>  $total_fee,
            'op_user_id'        => $this->wechat_config['MCH_ID'],
            'refund_fee_type'          => 'CNY',
        );

        cplog(serialize($sign_data), 'INFO');
        $sign = $this->setWxSign($sign_data);
        $sign_data['sign'] = $sign;
        ksort($sign_data);
        $xml = array_to_xml($sign_data);
        $post_url = 'https://api.mch.weixin.qq.com/secapi/pay/refund';
        $response_xml = $this->curl_post_ssl_app($post_url,$this->app_wx,$xml);
        $response_arr = $this->setXmlArray($response_xml);
        $info['sign'] = $sign_data['sign']  ? $sign_data['sign'] : '';
        $info['trade_no'] = $sign_data['out_refund_no'] ? $sign_data['out_refund_no'] : '';
        $info['order_sn'] = $sign_data['out_trade_no'] ? $sign_data['out_trade_no'] : '';
        $info['content'] = json_encode($sign_data).json_encode($response_arr);
        $info['pay_type'] = 4;
        $info['order_id'] = $data['id'] ? $data['id'] : '';
        $info['uid'] = $data['uid'] ? $data['uid'] : '';
        $info['ret_money'] = $response_arr['refund_fee'] ? $response_arr['refund_fee'] : $total_fee/100;
        $info['c_time'] = date('Y-m-d H:i:s',time());
        $refund_server = new \Common\Server\B\RefundServer();
        $info['trade_status'] = 99;
        if($response_arr['return_code'] == 'SUCCESS'){
            if($response_arr['result_code']=='SUCCESS'){
                $info['trade_status'] = 2;
            }else{
                cplog(serialize($sign_data), 'ERR');
                $info['trade_status'] = 0;
            }
        }else{
            $info['trade_status'] = 1;
        }
        $refund_server->refund_log($info);
        if($response_arr['return_code'] == 'SUCCESS'){
            return CpSuccess($response_arr['out_refund_no']);
        }
        return CpError(CP_ERROR, "请求失败");
    }
    //退款app读取证书
    function curl_post_ssl_app($url,$app_wx, $vars, $second=30,$aHeader=array())
    {
        $ch = curl_init();
        //超时时间
        curl_setopt($ch,CURLOPT_TIMEOUT,$second);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
        //这里设置代理，如果有的话
        //curl_setopt($ch,CURLOPT_PROXY, '10.206.30.98');
        //curl_setopt($ch,CURLOPT_PROXYPORT, 8080);
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);

        //以下两种方式需选择一种

        //第一种方法，cert 与 key 分别属于两个.pem文件
        //默认格式为PEM，可以注释
        curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
        curl_setopt($ch,CURLOPT_SSLCERT,dirname(__FILE__).'/Wxpay/'.$app_wx.'/cert.pem');
        //默认格式为PEM，可以注释
        curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
        curl_setopt($ch,CURLOPT_SSLKEY,dirname(__FILE__).'/Wxpay/'.$app_wx.'/private.pem');

        //第二种方式，两个文件合成一个.pem文件
        //curl_setopt($ch,CURLOPT_SSLCERT,getcwd().'/all.pem');
        if( count($aHeader) >= 1 ){
            curl_setopt($ch, CURLOPT_HTTPHEADER, $aHeader);
        }
        curl_setopt($ch,CURLOPT_POST, 1);
        curl_setopt($ch,CURLOPT_POSTFIELDS,$vars);
        $data = curl_exec($ch);
        if($data){
            curl_close($ch);
            return $data;
        }
        else {
            $error = curl_errno($ch);
            echo "call faild, errorCode:$error\n";
            curl_close($ch);
            return false;
        }
    }
    /**
     * 从xml中获取数组
     * @param $xmlData xml数据
     * @return array
     */
    public function setXmlArray($xmlData) {
        if ($xmlData) {
            $postObj = simplexml_load_string($xmlData, 'SimpleXMLElement', LIBXML_NOCDATA);
            if (! is_object($postObj)) {
                return false;
            }
            $array = json_decode(json_encode($postObj), true); // xml对象转数组
            return array_change_key_case($array, CASE_LOWER); // 所有键小写
        } else {
            return false;
        }
    }

    /**
     * 从xml中获取数组
     * @return array
     */
    public function getXmlArray() {
        $xmlData = file_get_contents("php://input");
        if ($xmlData) {
            $postObj = simplexml_load_string($xmlData, 'SimpleXMLElement', LIBXML_NOCDATA);
            if (! is_object($postObj)) {
                return false;
            }
            $array = json_decode(json_encode($postObj), true); // xml对象转数组
            return array_change_key_case($array, CASE_LOWER); // 所有键小写
        } else {
            return false;
        }
    }

    /**
     * https请求
     * @param $url 请求地址
     * @param $xml_data 请求xml数据
     * @return array
     */
    public function https_get($url,$xml_data) {
        $ch = curl_init();
        $header[] = "Content-type: text/xml";//定义content-type为xml
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_data);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            print curl_error($ch);
        }
        curl_close($ch);
        return $response;
    }

    /**
     * 验证服务器通知
     * @return array|bool
     */
    public function verifyNotify() {
        $xml = $this->getXmlArray();
        if (!$xml)  return false;
        $wx_sign = $xml['sign'];
        unset($xml['sign']);
        $cp_sign = $this->setWxSign($xml);
        if ($cp_sign != $wx_sign) {
            cplog('签名错误：'.serialize($xml).'平台生成签名：'.$cp_sign, WARN);
            return false;
        }elseif($xml['mch_id'] != $this->wechat_config['MCH_ID']) {
            cplog('商户号错误：'.  serialize($xml), WARN);
            return false;
        }
        $recharge_order_mod = new RechargeOrderModel();
        $recharge_order = $recharge_order_mod ->cp_getOne(array('order_sn'=>$xml['out_trade_no']), 'money');
        //支付debug
        if(PAY_DEBUG && in_array($_SERVER['HTTP_HOST'],$this->debug_host)){
            $xml['total_fee'] = $recharge_order['money']*100;
        } else if($recharge_order['money'] != ($xml['total_fee']/100)){
            cplog('金额错误：'.serialize($xml), ERR);
            return FALSE;
        }
        cplog(serialize($xml), INFO);
        return $xml;
    }

  
   /**
    * 
    * 查询订单，WxPayOrderQuery中out_trade_no、transaction_id至少填一个
    * appid、mchid、spbill_create_ip、nonce_str不需要填入
    * @param WxPayOrderQuery $inputObj
    * @param int $timeOut
    * @throws WxPayException
    * @return 成功时返回，其他抛异常
    * @author 476
    */
   public function orderQuery($order_sn) {
       
       //$requestData = $param;
       $requestData['appid'] = $this->wechat_config['APPID'];
       $requestData['mch_id'] = $this->wechat_config['MCH_ID'];
       $requestData['nonce_str'] = uniqid();
       $requestData['out_trade_no'] = $order_sn;//I('post.out_trade_no');
       $url = "https://api.mch.weixin.qq.com/pay/orderquery";
       $requestData['sign'] = $this->setWxSign($requestData);//签名
       //检测必填参数
       if(!$requestData['out_trade_no'] && !$requestData['transaction_id']) {
           return(array('code' => 1002, 'msg' => '订单查询接口中，out_trade_no、transaction_id至少填一个！'));
       }

       $xmlParams = array_to_xml($requestData);
       $response = $this->https_get($url, $xmlParams);
       $result = $this->setXmlArray($response);

       return $result;
   }
   
   /*
    * 撤销订单API WxPayOrderQuery中out_trade_no、transaction_id至少填一个
    * @throws WxPayException
    * @return 成功时返回，其他抛异常
    * @author 476
    */
   public function orderRevere ($order_sn) {
        $requestData['appid'] = $this->wechat_config['APPID'];
        $requestData['mch_id'] = $this->wechat_config['MCH_ID'];
        $requestData['nonce_str'] = uniqid();
        $requestData['out_trade_no'] = $order_sn;
        $url = "https://api.mch.weixin.qq.com/secapi/pay/reverse";
        $requestData['sign'] = $this->setWxSign($requestData);//签名
        
        //检测必填参数
       if(!$param['out_trade_no'] && !$param['transaction_id']) {
           return(array('code' => 1003, 'msg' => '订单查询接口中，out_trade_no、transaction_id至少填一个！'));
       }

       $xmlParams = array_to_xml($requestData);
       $response = $this->https_get($url, $xmlParams);
       $result = $this->setXmlArray($response);

       return $result;
   }
   
    /**
     * 支付成功发送模板消息
     * @param data json格式（看微信）
     * @return array
     */
    public function sendMsg($data){
        //获取微信token
        $key = 'wx_token:'.WXPAY_APPID;
        $redis = new \Common\Cache\RedisCache();
        $res = $redis ->get($key);
        if(!$res){
            $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&'
                    . 'appid='.WXPAY_APPID
                    . '&secret='.WXPAY_APPSECRET;
            $ret = mdsendsms($url);
            $res = json_decode($ret,TRUE);
            if($res['access_token']){
                $redis ->set($key, $res, 1140);
            } else {
                cplog('access_token获取失败:'.serialize(json_decode($res)), 'INFO');
            }
        }
        //发送模板消息
        $url1 = 'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token='.$res['access_token'];
        // 参数数组
        $data = json_encode($data);
        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $url1 );
        curl_setopt ( $ch, CURLOPT_POST, 1 );
        curl_setopt ( $ch, CURLOPT_HEADER, 0 );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data);
        $ret = curl_exec ( $ch );
        curl_close ($ch);
        cplog(serialize(json_decode($ret)), 'INFO');
        return json_decode($ret);
    }
    
    
    
    /**
     * 验证服务器通知
     * @return array|bool
     */
    public function posVerifyNotify() {
        $xml = $this->getXmlArray();
        if (!$xml)  return false;
        $wx_sign = $xml['sign'];
        unset($xml['sign']);
        $cp_sign = $this->setWxSign($xml);
        if ($cp_sign != $wx_sign) {
            cplog('pos签名错误：'.serialize($xml).'平台生成签名：'.$cp_sign, WARN);
            return false;
        }elseif($xml['mch_id'] != $this->wechat_config['MCH_ID']) {
            cplog('pos商户号错误：'.  serialize($xml), WARN);
            return false;
        }
        $order_money = M('order')->where(array('order_sn'=>$xml['out_trade_no']))->getField('money');
        //支付debug
        if(PAY_DEBUG && in_array($_SERVER['HTTP_HOST'],$this->debug_host)){
            $xml['total_fee'] = $order_money*100;
        } else if($order_money != ($xml['total_fee']/100)){
            cplog('pos金额错误：'.serialize($xml), ERR);
            return FALSE;
        }
        cplog(serialize($xml), INFO);
        return $xml;
    }
    //微信退款查询
    public function wx_drawback_query($data){
        $nonce_str = uniqid();
        $sign_data = array(
            'appid'             => $this->wechat_config['APPID'],
            'mch_id'            => $this->wechat_config['MCH_ID'],
            'nonce_str'         => $nonce_str,
            'transaction_id'    => $data['pay_sn'],
        );
        $sign = $this->setWxSign($sign_data);
        $sign_data['sign'] = $sign;
        ksort($sign_data);
        $xmlParams = array_to_xml($sign_data);
        $post_url = 'https://api.mch.weixin.qq.com/pay/refundquery';
        $response = $this->curl_post_ssl_app($post_url,$this->app_wx, $xmlParams);
        $result = $this->setXmlArray($response);
        if($result['return_code'] == 'SUCCESS'){
            if($result['result_code'] == "SUCCESS"){
                return CpSuccess($result['out_refund_no_0']);
            }else{
                return CpError(CP_ERROR,"处理中");
            }
        }else{
            return CpError(CP_ERROR,"请求错误");
        }
    }
   
   
}