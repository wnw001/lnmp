<?php

namespace app\common\server;

/**
 * Description of ItemServer
 * 2018-08-07
 * @author wuningwen
 */
class BaseServer {

    public function __construct() {
        
    }

       

}
